<?php
session_start();
include 'db.php'; // Ensure this file contains the database connection setup

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare the SQL statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['role'] = $row['role'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['email'] = $row['email'];

            // Redirect based on role
            switch ($row['role']) {
                case 'admin':
                    header("Location: admin_dashboard.php");
                    break;
                case 'faculty':
                    header("Location: faculty_dashboard.php");
                    break;
                case 'student':
                    header("Location: student-dashboard.php");
                    break;
                default:
                    $_SESSION['error'] = "Invalid role!";
                    header("Location: entry.php");
                    break;
            }
            exit();
        } else {
            $_SESSION['error'] = "Incorrect password!";
            echo "<script>alert('Incorrect password!');</script>";
        }
    } else {
        $_SESSION['error'] = "No user found with that email!";
        echo "<script>alert('No User found!');</script>";
    }

    $stmt->close();
} else {
    $_SESSION['error'] = "Invalid request method!";
    header("Location: entry.php");
}
$conn->close();
?>
