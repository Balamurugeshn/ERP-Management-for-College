<?php
session_start();
include("db.php");

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Fetch departments and classes for filtering
$departments_query = "SELECT * FROM departments";
$departments_result = mysqli_query($conn, $departments_query);

$classes_query = "SELECT * FROM classes";
$classes_result = mysqli_query($conn, $classes_query);

$selected_department = isset($_POST['department']) ? $_POST['department'] : '';
$selected_class = isset($_POST['class']) ? $_POST['class'] : '';

// Fetch student marks based on filters
$marks_query = "
    SELECT sm.id, st.student_name, s.subject_name, sm.marks, d.department_name, c.class_name
    FROM student_marks sm
    JOIN students st ON sm.student_id = st.id
    JOIN subjects s ON sm.subject_id = s.id
    JOIN departments d ON st.department_id = d.id
    JOIN classes c ON st.class_id = c.id
    WHERE ('$selected_department' = '' OR d.id = '$selected_department')
    AND ('$selected_class' = '' OR c.id = '$selected_class')
    ORDER BY d.department_name, c.class_name, st.student_name, s.subject_name
";
$marks_result = mysqli_query($conn, $marks_query);

// Handle updating marks
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_marks'])) {
    $mark_id = $_POST['mark_id'];
    $new_marks = $_POST['marks'];
    $update_query = "UPDATE student_marks SET marks='$new_marks' WHERE id='$mark_id'";
    mysqli_query($conn, $update_query);
    header("Location: admin_manage_marks.php"); // Redirect to avoid form resubmission
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Student Marks</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .filter-section {
            margin-bottom: 20px;
        }
        .filter-section select {
            padding: 5px;
            margin-right: 10px;
        }
        .back-button {
            margin-bottom: 20px;
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <a href="admin_dashboard.php" class="back-button">Back to Dashboard</a>
    
    <h1>Admin - Manage Student Marks</h1>
    
    <!-- Filter Section -->
    <div class="filter-section">
        <form method="POST">
            <label for="department">Department:</label>
            <select name="department" id="department">
                <option value="">All Departments</option>
                <?php while ($dept = mysqli_fetch_assoc($departments_result)) { ?>
                    <option value="<?php echo $dept['id']; ?>" <?php if ($dept['id'] == $selected_department) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($dept['department_name']); ?>
                    </option>
                <?php } ?>
            </select>

            <label for="class">Class:</label>
            <select name="class" id="class">
                <option value="">All Classes</option>
                <?php while ($class = mysqli_fetch_assoc($classes_result)) { ?>
                    <option value="<?php echo $class['id']; ?>" <?php if ($class['id'] == $selected_class) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($class['class_name']); ?>
                    </option>
                <?php } ?>
            </select>

            <button type="submit">Filter</button>
        </form>
    </div>

    <!-- Marks Table -->
    <table>
        <thead>
            <tr>
                <th>Student Name</th>
                <th>Department</th>
                <th>Class</th>
                <th>Subject</th>
                <th>Marks</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($marks_result)) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['department_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['class_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="mark_id" value="<?php echo $row['id']; ?>">
                            <input type="number" name="marks" value="<?php echo $row['marks']; ?>" min="0" max="100">
                            <button type="submit" name="update_marks">Update</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
