<?php
session_start();
include("db.php");

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

if (isset($_POST['add_faculty'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash(mysqli_real_escape_string($conn, $_POST['password']), PASSWORD_DEFAULT);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $dob = mysqli_real_escape_string($conn, $_POST['dob']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $contact_number = mysqli_real_escape_string($conn, $_POST['contact_number']);
    $blood_group = mysqli_real_escape_string($conn, $_POST['blood_group']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);
    $designation = mysqli_real_escape_string($conn, $_POST['designation']);
    $qualifications = mysqli_real_escape_string($conn, $_POST['qualifications']);
    $experience_years = intval($_POST['experience_years']);
    $office_location = mysqli_real_escape_string($conn, $_POST['office_location']);
    $bio = mysqli_real_escape_string($conn, $_POST['bio']);

    // Check if the username already exists
    $check_user_query = "SELECT user_id FROM users WHERE username='$username'";
    $check_user_result = mysqli_query($conn, $check_user_query);

    if (mysqli_num_rows($check_user_result) > 0) {
        $user_row = mysqli_fetch_assoc($check_user_result);
        $user_id = $user_row['user_id'];

        // Update user details
        $update_user_query = "UPDATE users SET email='$email', password='$password', role='faculty' WHERE user_id=$user_id";
        if (!mysqli_query($conn, $update_user_query)) {
            die("Failed to update user details: " . mysqli_error($conn));
        }

        // Update faculty profile details
        $update_profile_query = "INSERT INTO faculty_profiles (user_id, Name, email, department, designation, qualifications, experience_years, contact_number, office_location, bio)
                                 VALUES ($user_id, '$name', '$email', '$department', '$designation', '$qualifications', $experience_years, '$contact_number', '$office_location', '$bio')
                                 ON DUPLICATE KEY UPDATE Name='$name', email='$email', department='$department', designation='$designation', qualifications='$qualifications', experience_years=$experience_years, contact_number='$contact_number', office_location='$office_location', bio='$bio'";

        if (!mysqli_query($conn, $update_profile_query)) {
            die("Failed to update faculty profile details: " . mysqli_error($conn));
        }

    } else {
        // Insert new user
        $insert_user_query = "INSERT INTO users (username, email, password, role, department, mobile_number)
                      VALUES ('$username', '$email', '$password', 'faculty', '$department', '$contact_number')";


        if (!mysqli_query($conn, $insert_user_query)) {
            die("Failed to add faculty: " . mysqli_error($conn));
        }

        // Get the newly inserted user_id
        $user_id = mysqli_insert_id($conn);

        // Insert faculty profile details
        $insert_profile_query = "INSERT INTO faculty_profiles (user_id, Name, email, department, designation, qualifications, experience_years, contact_number, office_location, bio)
                                 VALUES ($user_id, '$name', '$email', '$department', '$designation', '$qualifications', $experience_years, '$contact_number', '$office_location', '$bio')";

        if (!mysqli_query($conn, $insert_profile_query)) {
            die("Failed to insert faculty profile details: " . mysqli_error($conn));
        }
    }

    header('Location: faculty_data.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Faculty</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: #007bff;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
        }
        .container {
            width: 60%;
            margin: 20px auto;
        }
        .add-form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .add-form input[type="text"], 
        .add-form input[type="email"], 
        .add-form input[type="password"], 
        .add-form input[type="number"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .add-form button {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .add-form button:hover {
            background-color: #0056b3;
        }
        .add-form .error {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<header>
    <h1>Add Faculty</h1>
</header>

<div class="container">
    <div class="add-form">
        <form action="add_faculty.php" method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="name" placeholder="Name" required>
            <input type="date" name="dob" placeholder="Date of Birth" required>
            <input type="text" name="address" placeholder="Address" required>
            <input type="text" name="contact_number" placeholder="Contact Number" required>
            <input type="text" name="blood_group" placeholder="Blood Group" required>
            <select name="gender" required>
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
            </select>
            <input type="text" name="department" placeholder="Department" required>
            <input type="text" name="designation" placeholder="Designation" required>
            <input type="text" name="qualifications" placeholder="Qualifications" required>
            <input type="number" name="experience_years" placeholder="Years of Experience" required>
            <input type="text" name="office_location" placeholder="Office Location" required>
            <textarea name="bio" placeholder="Biography"></textarea>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="add_faculty">Add Faculty</button>
        </form>
    </div>
</div>

</body>
</html>
