<?php
session_start();
include("db.php");

// Check if user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Handle form submission for adding a new announcement
if (isset($_POST['add_announcement'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);
    $username = $_SESSION['username']; // Assuming username is stored in the session
    $user_id = $_SESSION['user_id']; // Assuming user ID is stored in the session

    // Insert query
    $insert_query = "INSERT INTO announcements (title, content, announcement_date, user_id, username) 
                     VALUES ('$title', '$content', NOW(), '$user_id', '$username')";

    if (mysqli_query($conn, $insert_query)) {
        header("Location: announcements.php"); // Redirect to announcements page
        exit();
    } else {
        $error_message = "Failed to add new announcement: " . mysqli_error($conn);
    }
}
?>

<!-- HTML Form -->
<form method="POST" action="">
    <label for="title">Title:</label>
    <input type="text" id="title" name="title" required>
    
    <label for="content">Content:</label>
    <textarea id="content" name="content" required></textarea>
    
    <input type="submit" name="add_announcement" value="Add Announcement">
</form>
