<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smtecconnect";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Fetch announcements
$sql = "SELECT * FROM announcements ORDER BY announcement_date DESC";
$announcements = $conn->query($sql);

// Check if query was successful
if (!$announcements) {
    die("Query failed: " . $conn->error);
}
?>
