<?php
session_start();
include("db.php");

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'faculty') {
    header('Location: login.php');
    exit();
}

// Check if the faculty_id is set in the session
if (!isset($_SESSION['user_id'])) {
    echo "Faculty ID is not set in the session.";
    exit();
}

// Get the logged-in faculty member's ID
$faculty_id = $_SESSION['user_id'];

// Fetch subjects assigned to the faculty member
$subjects_query = "SELECT s.id AS subject_id, s.subject_name 
                   FROM faculty_subjects fs 
                   JOIN subjects s ON fs.subject_id = s.id 
                   WHERE fs.faculty_id = '$faculty_id'";
$subjects_result = mysqli_query($conn, $subjects_query);
$faculty_subjects = [];
while ($row = mysqli_fetch_assoc($subjects_result)) {
    $faculty_subjects[$row['subject_id']] = $row['subject_name'];
}

// Fetch student marks for the subjects taught by the faculty
$subject_ids = implode(',', array_keys($faculty_subjects));
$marks_query = "
    SELECT sm.id, st.student_name, s.subject_name, sm.marks
    FROM student_marks sm
    JOIN students st ON sm.student_id = st.id
    JOIN subjects s ON sm.subject_id = s.id
    WHERE sm.subject_id IN ($subject_ids)
    ORDER BY st.student_name, s.subject_name
";
$marks_result = mysqli_query($conn, $marks_query);

// Handle updating marks
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $mark_id = $_POST['mark_id'];
    $new_marks = $_POST['marks'];
    
    // Ensure the new marks are within a valid range (0 to 100)
    if (is_numeric($new_marks) && $new_marks >= 0 && $new_marks <= 100) {
        $update_query = "UPDATE student_marks SET marks='$new_marks' WHERE id='$mark_id'";
        mysqli_query($conn, $update_query);
        header("Location: faculty_manage_marks.php"); // Redirect to avoid form resubmission
        exit();
    } else {
        echo "Invalid marks. Please enter a number between 0 and 100.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Student Marks</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <h1>Manage Student Marks</h1>
    <table>
        <thead>
            <tr>
                <th>Student Name</th>
                <th>Subject</th>
                <th>Marks</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($marks_result)) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="mark_id" value="<?php echo $row['id']; ?>">
                            <input type="number" name="marks" value="<?php echo $row['marks']; ?>" min="0" max="100">
                            <button type="submit">Update</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
