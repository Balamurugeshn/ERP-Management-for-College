<?php
session_start();
include("db.php");

// Ensure that session variables are set
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Check if ID is set in the URL
if (!isset($_GET['id'])) {
    die("No student ID provided.");
}

$student_id = intval($_GET['id']);

// Fetch student data from the database
$query = "SELECT * FROM users 
          JOIN student_profiles ON users.user_id = student_profiles.user_id 
          WHERE users.user_id = $student_id AND users.role = 'student'";
$result = mysqli_query($conn, $query);

// Check for query errors
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

// Fetch the student data
$student = mysqli_fetch_assoc($result);

// Check if student data is found
if (!$student) {
    die("Student not found.");
}

// Handle form submission for updating student data
if (isset($_POST['update_student'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);
    $class = mysqli_real_escape_string($conn, $_POST['class']);
    $section = mysqli_real_escape_string($conn, $_POST['section']);
    $mobile_number = mysqli_real_escape_string($conn, $_POST['mobile_number']);
    
    // Update users table
    $update_users_query = "UPDATE users SET username='$username', email='$email' WHERE user_id=$student_id";
    $update_profiles_query = "UPDATE student_profiles SET department='$department', class='$class', section='$section', mobile_number='$mobile_number' WHERE user_id=$student_id";
    
    if (mysqli_query($conn, $update_users_query) && mysqli_query($conn, $update_profiles_query)) {
        // If the updated user is the currently logged-in user, update the session variables
        if ($_SESSION['username'] == $username) {
            $_SESSION['role'] = $role;
        }
        
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    document.getElementById('update-dialog').style.display = 'block';
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000); // Reload after 2 seconds
                });
              </script>";
    } else {
        $update_error = "Failed to update student data: " . mysqli_error($conn);
    }
}

// Handle student deletion
if (isset($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    $delete_query = "DELETE FROM users WHERE user_id = $delete_id";
    if (mysqli_query($conn, $delete_query)) {
        header('Location: student_data.php');
        exit();
    } else {
        $delete_error = "Failed to delete student: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: #003366;
            color: #fff;
            padding: 10px 0;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        header h1 {
            margin: 0;
        }
        .container {
            width: 90%;
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .back-to-list {
            display: inline-block;
            margin-bottom: 20px;
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }
        .back-to-list:hover {
            background-color: #0056b3;
        }
        h2 {
            margin-top: 0;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .error-message {
            color: red;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .dialog-box {
            display: none;
            position: fixed;
            top: 10%;
            left: 50%;
            transform: translateX(-50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        .dialog-box p {
            margin: 0;
        }
        .dialog-box button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .dialog-box button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<header>
    <h1>Edit Student</h1>
</header>

<div class="container">
    <a href="student_data.php" class="back-to-list">Back to Student List</a>
    <h2>Edit Student Information</h2>
    
    <?php if (isset($update_error)) { ?>
        <p class="error-message"><?php echo $update_error; ?></p>
    <?php } ?>
    
    <form action="edit_profile.php?id=<?php echo $student_id; ?>" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($student['username'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($student['email'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
        
        <label for="department">Department:</label>
        <input type="text" id="department" name="department" value="<?php echo htmlspecialchars($student['department'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
        
        <label for="class">Class:</label>
        <input type="text" id="class" name="class" value="<?php echo htmlspecialchars($student['class'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
        
        <label for="section">Section:</label>
        <input type="text" id="section" name="section" value="<?php echo htmlspecialchars($student['section'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
        
        <label for="mobile_number">Mobile Number:</label>
        <input type="text" id="mobile_number" name="mobile_number" value="<?php echo htmlspecialchars($student['mobile_number'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
        
        <button type="submit" name="update_student">Update Student</button>
    </form>
</div>

<script>
    // Handle the dialog box visibility and auto-refresh
    document.addEventListener('DOMContentLoaded', function() {
        if (document.getElementById('update-dialog')) {
            document.getElementById('update-dialog').style.display = 'block';
            setTimeout(function() {
                window.location.reload();
            }, 2000); // Reload after 2 seconds
        }
    });
</script>

</body>
</html>
