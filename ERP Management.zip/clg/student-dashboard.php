<?php
session_start();
include 'db.php'; // Ensure this file contains the database connection setup

// Check if user is logged in and has the role of 'student'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: entry.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch profile information
$profile_query = "SELECT * FROM student_profiles WHERE user_id = ?";
$stmt = $conn->prepare($profile_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$profile_result = $stmt->get_result();

if ($profile_result->num_rows > 0) {
    $profile = $profile_result->fetch_assoc();
} else {
    $_SESSION['error'] = "Profile not found!";
    header("Location: entry.php");
    exit();
}

// Fetch notifications for the logged-in student
$notifications_query = "SELECT * FROM announcements WHERE expires_at > NOW() ORDER BY created_at DESC";
$notifications_result = $conn->query($notifications_query);

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            line-height: 1.6;
            margin: 0;
        }
        header, footer {
            background-color: #003366;
            color: #fff;
            padding: 20px;
            text-align: center;
            position: relative;
        }
        
        main {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .profile-info, .card {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .profile-info h2, .card h3 {
            font-size: 1.6em;
            margin-bottom: 10px;
        }
        .profile-info table {
            width: 100%;
            border-collapse: collapse;
        }
        .profile-info table, .profile-info th, .profile-info td {
            border: 1px solid #ddd;
        }
        .profile-info th, .profile-info td {
            padding: 10px;
            text-align: left;
        }
        .profile-info th {
            background-color: #f4f4f4;
        }
        .profile-image-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        .profile-image {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .dashboard-cards {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .card {
            flex: 1;
            min-width: 250px;
        }
        .logout-button {
            background-color: #d9534f;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            position: absolute;
            right: 20px;
            top: 20px;
        }
        .logout-button:hover {
            background-color: #c9302c;
        }
        .edit-button {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background-color: #337ab7;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .edit-button:hover {
            background-color: #286090;
        }

        /* Notification Styles */
        .notification-bell {
            position: absolute;
            right: 70px;
            top: 20px;
            cursor: pointer;
            margin-left: 20px;
        }
        .notification-dropdown {
            display: none;
            position: absolute;
            top: 60px;
            right: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            width: 300px;
            max-height: 400px;
            overflow-y: auto;
            z-index: 1000;
        }
        .notification-dropdown.show {
            display: block;
        }
        .notification-item {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        .notification-item:last-child {
            border-bottom: none;
        }
        .notification-item.unread {
            background-color: #f9f9f9;
        }
        .notification-item a {
            text-decoration: none;
            color: #003366;
        }
        .notification-item a:hover {
            text-decoration: underline;
        }
        .notification-item .date {
            font-size: 0.9em;
            color: #666;
        }
    </style>
    <script>
        function toggleNotifications() {
            const dropdown = document.getElementById('notification-dropdown');
            dropdown.classList.toggle('show');
        }
    </script>
</head>
<body>
    <header>
        <h1>Student Dashboard</h1>
        <!-- Notification Bell Icon -->
        <img src="notification_bell_icon.png" alt="Notifications" class="notification-bell" onclick="toggleNotifications()">
        <!-- Logout Button -->
        <a href="logout.php" class="logout-button">Logout</a>
    </header>
    <main>
        <!-- Profile Information Section -->
        <div class="profile-info">
            <h2>Profile Information</h2>
            <!-- Centered Profile Picture -->
            <div class="profile-image-container">
                <img src="uploads/<?php echo htmlspecialchars($profile['profile_picture']); ?>" alt="Profile Picture" class="profile-image">
            </div>
            <table>
                <tr><th>Name</th><td><?php echo htmlspecialchars($profile['name']); ?></td></tr>
                <tr><th>Date of Birth</th><td><?php echo htmlspecialchars($profile['dob']); ?></td></tr>
                <tr><th>Email</th><td><?php echo htmlspecialchars($profile['email']); ?></td></tr>
                <tr><th>Phone</th><td><?php echo htmlspecialchars($profile['mobile_number']); ?></td></tr>
                <tr><th>Address</th><td><?php echo htmlspecialchars($profile['address']); ?></td></tr>
                <tr><th>Department</th><td><?php echo htmlspecialchars($profile['department']); ?></td></tr>
                <tr><th>Class</th><td><?php echo htmlspecialchars($profile['class']); ?></td></tr>
                <tr><th>Section</th><td><?php echo htmlspecialchars($profile['section']); ?></td></tr>
            </table>
            <!-- Edit Profile Button -->
            <a href="edit_profile.php" class="edit-button">Edit Profile</a>
        </div>

        <!-- Dashboard Cards -->
        <div class="dashboard-cards">
            <!-- Marks Card -->
            <div class="card">
                <h3>Marks</h3>
                <p>View your exam marks.</p>
                <a href="view_marks.php">View Marks</a>
            </div>

            <!-- Attendance Card -->
            <div class="card">
                <h3>Attendance</h3>
                <p>Check your attendance record.</p>
                <a href="view_attendance.php">View Attendance</a>
            </div>

            <!-- Study Materials Card -->
            <div class="card">
                <h3>Study Materials</h3>
                <p>Access study materials uploaded by your teachers.</p>
                <a href="view_study_materials.php">View Materials</a>
            </div>

            <!-- Timetable Card -->
            <div class="card">
                <h3>Timetable</h3>
                <p>Check your class timetable.</p>
                <a href="view_timetable.php">View Timetable</a>
            </div>

            <!-- Complaint Card -->
            <div class="card">
                <h3>Raise a Complaint</h3>
                <p>Have any issues? Raise a complaint here.</p>
                <a href="raise_complaint.php">Raise Complaint</a>
            </div>
        </div>
    </main>
<!-- Notification Dropdown -->
<div id="notification-dropdown" class="notification-dropdown">
    <?php
    if ($notifications_result->num_rows > 0) {
        while ($notification = $notifications_result->fetch_assoc()) {
            echo '<div class="notification-item">';
            echo '<a href="#">';
            echo '<div class="notification-title">' . htmlspecialchars($notification['title']) . '</div>';
            echo '<div class="notification-content">' . htmlspecialchars($notification['content']) . '</div>';
            echo '<div class="notification-date">' . htmlspecialchars($notification['created_at']) . '</div>';
            echo '</a>';
            echo '</div>';
        }
    } else {
        echo '<div class="notification-item">No notifications available.</div>';
    }
    ?>
</div>


    <footer>
        &copy; 2024 SMTECConnect+
    </footer>
</body>
</html>
