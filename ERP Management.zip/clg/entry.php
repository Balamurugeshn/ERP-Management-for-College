<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="loginstyles.css">
    <style>
        .error-msg {
            color: red;
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }
    </style>
</head>
<body>
    <div id="login">
        <div class="login-container">
            <div class="logo-container">
                <img src="smt_logo.png" alt="SMTECConnect+ Logo" class="logo">
            </div>
            <h1>Login</h1>
            <form action="login.php" method="post">
                <label for="role">Select Role</label>
                <select id="role" name="role" required>
                    <option value="">Select a role</option>
                    <option value="admin">Admin</option>
                    <option value="faculty">Faculty</option>
                    <option value="student">Student</option>
                </select>

                <label for="email">Username or Email</label>
                <input type="text" id="email" name="email" placeholder="Enter your username or email" required>
                <div id="emailError" class="error-msg"></div>
                
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required>
                <div id="passwordError" class="error-msg"></div>

                <button type="submit">Login</button>
            </form>
            <a href="send_otp.php" class="forgot-password-link">Forgot Password?</a>
        </div>
    </div>
</body>
</html>
