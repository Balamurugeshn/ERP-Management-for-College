<?php
session_start();
include 'db.php'; // Ensure this file contains the database connection setup

// Check if the user is logged in and has the role of 'faculty'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'faculty') {
    header("Location: entry.php");
    exit();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Complaints</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            line-height: 1.6;
            margin: 0;
        }
        header, footer {
            background-color: #003366;
            color: #fff;
            padding: 20px;
            text-align: center;
            position: relative;
        }
        main {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .card {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            cursor: pointer;
        }
        .card h3 {
            margin-top: 0;
        }
        .card:hover {
            background-color: #f9f9f9;
        }
        .logout-button {
            background-color: #d9534f;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            position: absolute;
            right: 20px;
            top: 20px;
        }
        .logout-button:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
    <header>
        <h1>Manage Complaints</h1>
    </header>
    <main>
        <div class="card" onclick="window.location.href='view_complaints.php?section=raise_complaint'">
            <h3>Raise Complaint as Faculty</h3>
            <p>Submit a new complaint as a faculty member.</p>
        </div>
        <div class="card" onclick="window.location.href='view_complaints.php?section=student_complaints'">
            <h3>Complaints from Students</h3>
            <p>View complaints that have been raised by students.</p>
        </div>
    </main>
   
</body>
</html>
