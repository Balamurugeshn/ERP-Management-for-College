<?php
session_start(); // Start the session

// Check if the session exists
if (isset($_SESSION['user_id'])) {
    // Destroy all session data
    session_unset();
    session_destroy();
    
    // Redirect to the homepage
    header("Location: index.html");
    exit();
} else {
    // If no session exists, redirect to the homepage directly
    header("Location: index.html");
    exit();
}
?>
