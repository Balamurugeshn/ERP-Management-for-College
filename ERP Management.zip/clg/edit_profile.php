<?php
session_start();
include 'db.php'; // Include the database connection

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if the user is logged in and has the role of 'student'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: entry.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch profile information
$profile_query = "SELECT * FROM student_profiles WHERE user_id = ?";
$stmt = $conn->prepare($profile_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$profile_result = $stmt->get_result();

if ($profile_result->num_rows > 0) {
    $profile = $profile_result->fetch_assoc();
} else {
    $_SESSION['error'] = "Profile not found!";
    header("Location: student-dashboard.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'] ?? '';  // Provide default empty strings
    $dob = $_POST['dob'] ?? '';
    $email = $_POST['email'] ?? '';
    $mobile_number = $_POST['mobile_number'] ?? '';
    $address = $_POST['address'] ?? '';
    $department = $_POST['department'] ?? '';
    $class = $_POST['class'] ?? '';
    $section = $_POST['section'] ?? '';

    // Check if the email is already in use
    $email_check_query = "SELECT user_id FROM users WHERE email = ? AND user_id != ?";
    $stmt = $conn->prepare($email_check_query);
    $stmt->bind_param("si", $email, $user_id);
    $stmt->execute();
    $email_check_result = $stmt->get_result();

    if ($email_check_result->num_rows > 0) {
        $_SESSION['error'] = "The email address is already in use by another account.";
        header("Location: edit_profile.php");
        exit();
    }

    // Update student_profiles table
    $update_profile_query = "UPDATE student_profiles SET name = ?, dob = ?, email = ?, mobile_number = ?, address = ?, department = ?, class = ?, section = ? WHERE user_id = ?";
    $stmt = $conn->prepare($update_profile_query);

    if ($stmt === false) {
        die("Failed to prepare statement for profile update: " . $conn->error);
    }

    $stmt->bind_param("ssssssssi", $name, $dob, $email, $mobile_number, $address, $department, $class, $section, $user_id);

    if (!$stmt->execute()) {
        echo "Error updating profile: " . $stmt->error;
        exit();
    }

    // Update users table
    $update_users_query = "UPDATE users SET email = ?, username = ?,mobile_number = ? WHERE user_id = ?";
    $stmt = $conn->prepare($update_users_query);

    if ($stmt === false) {
        die("Failed to prepare statement for users update: " . $conn->error);
    }

    $username = $name; // Use name as username or update as needed
    $stmt->bind_param("sssi", $email, $username,$mobile_number,$user_id);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Profile updated successfully!";
    } else {
        echo "Error updating user information: " . $stmt->error;
        exit();
    }

    // Redirect to student-dashboard.php
    header("Location: student-dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <style>
        /* CSS Styling */
        /* (Keep your styling as it is) */
        <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #007bff;
            color: #ffffff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: #ffffff;
            text-decoration: none;
            font-size: 16px;
            margin-left: 20px;
        }

        .header a:hover {
            text-decoration: underline;
        }

        .edit-profile-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            width: 100%;
            margin: 40px auto;
        }

        .edit-profile-container h1 {
            text-align: center;
            color: #333333;
            margin-bottom: 20px;
        }

        .edit-profile-container form {
            display: flex;
            flex-direction: column;
        }

        .edit-profile-container label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #555555;
        }

        .edit-profile-container input[type="text"],
        .edit-profile-container input[type="email"],
        .edit-profile-container input[type="date"],
        .edit-profile-container textarea {
            padding: 10px;
            border: 1px solid #cccccc;
            border-radius: 5px;
            margin-bottom: 15px;
            font-size: 16px;
            color: #333333;
        }

        .edit-profile-container input[type="submit"] {
            padding: 12px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .edit-profile-container input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .edit-profile-container .back-button {
            text-align: center;
            margin-top: 15px;
        }

        .edit-profile-container .back-button a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .edit-profile-container .back-button a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <div class="header">
        <h1>Edit Profile</h1>
        <div>
            <a href="student-dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <!-- Edit Profile Form -->
    <div class="edit-profile-container">
        <h1>Edit Profile</h1>
        <form action="edit_profile.php" method="post">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($profile['name']); ?>" required>

            <label for="dob">Date of Birth:</label>
            <input type="date" id="dob" name="dob" value="<?php echo htmlspecialchars($profile['dob']); ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($profile['email']); ?>" required>

            <label for="mobile_number">Mobile Number:</label>
            <input type="text" id="mobile_number" name="mobile_number" value="<?php echo htmlspecialchars($profile['mobile_number']); ?>" required>

            <label for="address">Address:</label>
            <textarea id="address" name="address" rows="4" required><?php echo htmlspecialchars($profile['address']); ?></textarea>

            <label for="department">Department:</label>
            <input type="text" id="department" name="department" value="<?php echo htmlspecialchars($profile['department']); ?>" required>

            <label for="class">Class:</label>
            <input type="text" id="class" name="class" value="<?php echo htmlspecialchars($profile['class']); ?>" required>

            <label for="section">Section:</label>
            <input type="text" id="section" name="section" value="<?php echo htmlspecialchars($profile['section']); ?>" required>

            <input type="submit" value="Update Profile">
        </form>

        <div class="back-button">
            <a href="student-dashboard.php">Back to Dashboard</a>
        </div>
    </div>
</body>
</html>
