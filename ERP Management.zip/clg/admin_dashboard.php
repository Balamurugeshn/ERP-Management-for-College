<?php
session_start();
include("db.php");

// Ensure that session variables are set (this is a safeguard)
if (!isset($_SESSION['username'])) {
    header('Location: login.php'); // Redirect to login if session is not set
    exit();
}

// Fetch total users
$total_users_query = "SELECT COUNT(*) AS total_users FROM users";
$total_users_result = mysqli_query($conn, $total_users_query);
$total_users_row = mysqli_fetch_assoc($total_users_result);
$total_users = $total_users_row['total_users'];

// Fetch today's new registrations
$date_today = date('Y-m-d');
$new_registrations_query = "SELECT COUNT(*) AS new_registrations FROM users WHERE DATE(created_at) = '$date_today'";
$new_registrations_result = mysqli_query($conn, $new_registrations_query);
$new_registrations_row = mysqli_fetch_assoc($new_registrations_result);
$new_registrations = $new_registrations_row['new_registrations'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="admin_dashboard.css">
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('overlay');
            const mainContent = document.getElementById('main-content');

            if (sidebar.classList.contains('open')) {
                sidebar.classList.remove('open');
                mainContent.classList.remove('sidebar-open');
                overlay.style.display = 'none';
            } else {
                sidebar.classList.add('open');
                mainContent.classList.add('sidebar-open');
                overlay.style.display = 'block';
            }
        }

        function toggleProfile() {
            const profileCard = document.querySelector('.profile-card');
            profileCard.classList.toggle('visible');
        }

        function closeSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('overlay');
            const mainContent = document.getElementById('main-content');

            sidebar.classList.remove('open');
            mainContent.classList.remove('sidebar-open');
            overlay.style.display = 'none';
        }

        document.addEventListener('DOMContentLoaded', () => {
            document.getElementById('overlay').addEventListener('click', closeSidebar);
        });
    </script>
</head>
<body>

    <!-- Header -->
    <header>
        <div class="menu-toggle" onclick="toggleSidebar()">&#9776;</div>
        <h1>Admin Dashboard!</h1>
        <div class="header-buttons">
            <button class="profile-btn" onclick="toggleProfile()">
                <i class="fa-regular fa-address-card"></i>
            </button>            
        </div>
    </header>

    <!-- Sidebar -->
    <nav id="sidebar">
        <ul>
            <li><a href="#" class="active">Dashboard</a></li>
            <li><a href="#">Users</a></li>
            <li><a href="#">Settings</a></li>
            <li><a href="#">Reports</a></li>
        </ul>
    </nav>

    <!-- Overlay -->
    <div id="overlay"></div>

    <!-- Main content -->
    <div id="main-content">
        <br><br>
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        <div class="dashboard-cards">
            <div class="dashboard-card">
                <h3>Total Users</h3>
                <p><?php echo $total_users; ?></p>
            </div>
            <div class="dashboard-card">
                <h3>New Registrations</h3>
                <p><?php echo $new_registrations; ?></p>
            </div>
            <div class="dashboard-card" onclick="window.location.href='student_data.php'">
                <h3>Student Data</h3>
                <p>View and manage student data</p>
            </div>
            <div class="dashboard-card" onclick="window.location.href='faculty_data.php'">
                <h3>Faculty Data</h3>
                <p>View and manage faculty data</p>
            </div>
            <div class="dashboard-card" onclick="window.location.href='announcements.php'">
                <h3>Announcements</h3>
                <p>Manage and post announcements</p>
            </div>
            <!-- New Cards -->
            <div class="dashboard-card" onclick="window.location.href='complaints.php'">
                <h3>Complaints</h3>
                <p>Read and manage complaints</p>
            </div>
            <div class="dashboard-card" onclick="window.location.href='student_marks.php'">
                <h3>Student Marks</h3>
                <p>View and manage student marks</p>
            </div>
            <div class="dashboard-card" onclick="window.location.href='study_materials.php'">
                <h3>Study Materials</h3>
                <p>View and manage study materials</p>
            </div>
            <!-- New Attendance Report Card -->
            <div class="dashboard-card" onclick="window.location.href='attendance_report.php'">
                <h3>Attendance Report</h3>
                <p>View and manage attendance reports</p>
            </div>
        </div>

        <!-- Admin Profile Section -->
        <div class="profile-card">
            <img src="profile.jpg" alt="Admin Avatar">
            <h3><?php echo htmlspecialchars($_SESSION['username']); ?></h3>
            <p>Email: <?php echo htmlspecialchars($_SESSION['email']); ?></p>
            <p>Role: <?php echo htmlspecialchars($_SESSION['role']); ?></p>
            <button onclick="window.location.href='edit_profile.php'">Edit Profile</button>
            <button onclick="window.location.href='logout.php'" class="logout-btn">Logout</button>
        </div>
    </div>

</body>
</html>
