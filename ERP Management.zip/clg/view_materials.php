<?php
session_start();
include("db.php");

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'student') {
    header('Location: login.php');
    exit();
}

// Handle file download
if (isset($_GET['download']) && !empty($_GET['file'])) {
    $file = basename($_GET['file']); // Prevent directory traversal attacks
    $file_path = __DIR__ . '/uploads/' . $file;
    
    if (file_exists($file_path)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        exit;
    } else {
        echo "File does not exist.";
    }
} else {
    echo "Invalid request.";
}
?>
