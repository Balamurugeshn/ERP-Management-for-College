<?php
session_start();
include("db.php");

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Handle attendance updates
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_attendance'])) {
    $attendance_id = $_POST['attendance_id'];
    $new_status = $_POST['status'];
    $update_query = "UPDATE attendance SET status='$new_status' WHERE attendance_id='$attendance_id'";
    mysqli_query($conn, $update_query);
    header("Location: admin_manage_attendance.php"); // Redirect to avoid form resubmission
    exit();
}

// Fetch attendance records
$attendance_query = "
    SELECT a.attendance_id, u.username, a.date, a.status, a.remarks
    FROM attendance a
    JOIN users u ON a.user_id = u.user_id
    ORDER BY u.username, a.date
";
$attendance_result = mysqli_query($conn, $attendance_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Student Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <h1>Admin - Manage Student Attendance</h1>
    
    <!-- Attendance Table -->
    <table>
        <thead>
            <tr>
                <th>Student Name</th>
                <th>Date</th>
                <th>Status</th>
                <th>Remarks</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($attendance_result)) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                    <td><?php echo htmlspecialchars($row['date']); ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="attendance_id" value="<?php echo $row['attendance_id']; ?>">
                            <select name="status">
                                <option value="Present" <?php if ($row['status'] == 'Present') echo 'selected'; ?>>Present</option>
                                <option value="Absent" <?php if ($row['status'] == 'Absent') echo 'selected'; ?>>Absent</option>
                                <option value="On Duty" <?php if ($row['status'] == 'On Duty') echo 'selected'; ?>>On Duty</option>
                            </select>
                            <button type="submit" name="update_attendance">Update</button>
                        </form>
                    </td>
                    <td><?php echo htmlspecialchars($row['remarks']); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
