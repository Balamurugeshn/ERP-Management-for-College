<?php
session_start();
include 'db.php'; // Ensure this file contains the database connection setup

// Check if user is logged in and has the role of 'student'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: entry.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['profile_picture'])) {
    $file = $_FILES['profile_picture'];

    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['error'] = "Error uploading file.";
    } else {
        // Validate file type and size
        $allowed_types = ['image/jpeg', 'image/png'];
        if (!in_array($file['type'], $allowed_types)) {
            $_SESSION['error'] = "Invalid file type. Only JPEG and PNG are allowed.";
        } elseif ($file['size'] > 2 * 1024 * 1024) { // 2MB max size
            $_SESSION['error'] = "File size exceeds the 2MB limit.";
        } else {
            // Define upload directory and file path
            $upload_dir = 'uploads/';
            $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $new_file_name = $user_id . '.' . $file_extension;
            $file_path = $upload_dir . $new_file_name;

            // Move uploaded file to the target directory
            if (move_uploaded_file($file['tmp_name'], $file_path)) {
                // Update profile picture in the database
                $update_query = "UPDATE student_profiles SET profile_picture = ? WHERE user_id = ?";
                $stmt = $conn->prepare($update_query);
                $stmt->bind_param("si", $new_file_name, $user_id);
                if ($stmt->execute()) {
                    $_SESSION['success'] = "Profile picture updated successfully!";
                } else {
                    $_SESSION['error'] = "Failed to update profile picture.";
                }
            } else {
                $_SESSION['error'] = "Failed to move uploaded file.";
            }
        }
    }
}

// Fetch the current profile picture
$profile_query = "SELECT profile_picture FROM student_profiles WHERE user_id = ?";
$stmt = $conn->prepare($profile_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$profile_result = $stmt->get_result();
$profile = $profile_result->fetch_assoc();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile Picture</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        h1 {
            font-size: 1.8em;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input[type="file"] {
            border: 1px solid #ddd;
            padding: 10px;
            border-radius: 5px;
            width: 100%;
        }
        .form-group button {
            background-color: #5bc0de;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color: #31b0d5;
        }
        .error, .success {
            color: red;
            margin-bottom: 20px;
        }
        .success {
            color: green;
        }
        .current-image {
            margin-bottom: 20px;
        }
        .current-image img {
            max-width: 200px;
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Profile Picture</h1>
        <?php if (isset($_SESSION['success'])): ?>
            <p class="success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></p>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <p class="error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
        <?php endif; ?>

        <div class="current-image">
            <?php if ($profile['profile_picture']): ?>
                <img src="uploads/<?php echo htmlspecialchars($profile['profile_picture']); ?>" alt="Current Profile Picture">
            <?php else: ?>
                <p>No profile picture set.</p>
            <?php endif; ?>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="profile_picture">Select New Profile Picture</label>
                <input type="file" name="profile_picture" id="profile_picture" accept="image/jpeg, image/png">
            </div>
            <div class="form-group">
                <button type="submit">Upload</button>
            </div>
        </form>
    </div>
</body>
</html>
