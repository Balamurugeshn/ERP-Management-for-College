<?php
// Include the connection file
include 'db.php'; // Adjust the path if needed

// User data
$users = [
    ['username' => 'principal', 'email' => 'admin@example.com', 'password' => 'smtec@123' ]
];

// Prepare SQL statement
$stmt = $conn->prepare("INSERT INTO Users (username, email, password) VALUES (?, ?, ?)");

// Check if preparation was successful
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

// Bind parameters
$stmt->bind_param("sss", $username, $email, $hashed_password);

// Loop through users and insert each one
foreach ($users as $user) {
    $username = $user['username'];
    $email = $user['email'];
    $hashed_password = password_hash($user['password'], PASSWORD_DEFAULT);

    // Execute the statement
    if (!$stmt->execute()) {
        echo "Error inserting user: " . $stmt->error . "<br>";
    } else {
        echo "Inserted user: $username successfully<br>";
    }
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
