<?php
session_start();
include 'db.php'; // Ensure this file contains the database connection setup

// Check if the user is logged in and has the role of 'faculty'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'faculty') {
    header("Location: entry.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get section parameter
$section = isset($_GET['section']) ? $_GET['section'] : '';

if ($section === 'raise_complaint') {
    // Handle faculty complaint submission
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_faculty_complaint'])) {
        $category = $_POST['faculty_category'];
        $complaint_text = $_POST['faculty_complaint_text'];

        if (empty($category) || empty($complaint_text)) {
            $error_message = "All fields are required.";
        } else {
            $query = "INSERT INTO complaints (user_id, category, complaint_text, created_at) VALUES (?, ?, ?, NOW())";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("iss", $user_id, $category, $complaint_text);

            if ($stmt->execute()) {
                $success_message = "Your complaint has been submitted successfully.";
            } else {
                $error_message = "Failed to submit your complaint. Please try again.";
            }

            $stmt->close();
        }
    }
} elseif ($section === 'student_complaints') {
    // Fetch complaints from students only
    $student_complaints_query = "
        SELECT c.* 
        FROM complaints c
        JOIN users u ON c.user_id = u.user_id
        WHERE u.role = 'student'
        ORDER BY c.created_at DESC
    ";
    $student_complaints_result = $conn->query($student_complaints_query);
} elseif ($section === 'my_complaints') {
    // Fetch complaints submitted by the logged-in faculty
    $my_complaints_query = "
        SELECT * 
        FROM complaints 
        WHERE user_id = ?
        ORDER BY created_at DESC
    ";
    $stmt = $conn->prepare($my_complaints_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $my_complaints_result = $stmt->get_result();
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $section === 'raise_complaint' ? 'Raise Complaint' : ($section === 'student_complaints' ? 'Student Complaints' : 'My Complaints'); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            line-height: 1.6;
            margin: 0;
        }
        header, footer {
    background-color: #003366; /* Header color */
    color: #fff;
    padding: 20px;
    text-align: center;
}

.button {
    display: inline-block;
    padding: 10px 20px;
    font-size: 16px;
    font-weight: bold;
    text-align: center;
    text-decoration: none;
    color: #fff;
    background-color: #003366; /* Match button color with header color */
    border-radius: 5px;
    margin: 10px 0;
    cursor: pointer;
    border: none;
}

.button:hover {
    background-color: #002244; /* Slightly darker shade for hover effect */
}

        main {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .card, .complaint-section {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .complaint-section h3 {
            margin-top: 0;
        }
        .complaint-section table {
            width: 100%;
            border-collapse: collapse;
        }
        .complaint-section table, .complaint-section th, .complaint-section td {
            border: 1px solid #ddd;
        }
        .complaint-section th, .complaint-section td {
            padding: 10px;
            text-align: left;
        }
        .complaint-section th {
            background-color: #f4f4f4;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group select, .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-group button {
            background-color: #4CAF50; /* Green color for the button */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color: #45a049; /* Slightly darker green for hover effect */
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            text-align: center;
            text-decoration: none;
            color: #fff;
            background-color: #007bff; /* Blue color for the button */
            border-radius: 5px;
            margin: 10px 0;
            cursor: pointer;
        }
        .button:hover {
            background-color: #0056b3; /* Slightly darker blue for hover effect */
        }
        .message {
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <header>
        <h1><?php echo $section === 'raise_complaint' ? 'Raise a Complaint' : ($section === 'student_complaints' ? 'Student Complaints' : 'My Complaints'); ?></h1>
    </header>
    <main>
        <div class="card">
            <a href="faculty_dashboard.php" class="button">Back to Dashboard</a>
            <?php if ($section === 'raise_complaint'): ?>
                <div class="card complaint-section">
                    <h3>Raise Complaint as Faculty</h3>
                    <?php if (isset($success_message)): ?>
                        <div class="message success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    <?php if (isset($error_message)): ?>
                        <div class="message error"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <form method="post" action="">
                        <div class="form-group">
                            <label for="faculty_category">Category:</label>
                            <select id="faculty_category" name="faculty_category">
                                <option value="">Select Category</option>
                                <option value="canteen">Canteen</option>
                                <option value="restroom">Restroom</option>
                                <option value="department">Department</option>
                                <option value="ground">Ground</option>
                                <option value="campus">Campus</option>
                                <option value="faculty">Faculty</option>
                                <option value="others">Others</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="faculty_complaint_text">Complaint:</label>
                            <textarea id="faculty_complaint_text" name="faculty_complaint_text" rows="4"></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" name="submit_faculty_complaint">Submit Complaint</button>
                        </div>
                    </form>
                </div>
            <?php elseif ($section === 'student_complaints'): ?>
                <div class="card complaint-section">
                    <h3>Complaints from Students</h3>
                    <?php if ($student_complaints_result->num_rows > 0): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Category</th>
                                    <th>Complaint</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($complaint = $student_complaints_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($complaint['complaint_id']); ?></td>
                                        <td><?php echo htmlspecialchars($complaint['category']); ?></td>
                                        <td><?php echo htmlspecialchars($complaint['complaint_text']); ?></td>
                                        <td><?php echo htmlspecialchars($complaint['created_at']); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>No complaints available.</p>
                    <?php endif; ?>
                </div>
            <?php elseif ($section === 'my_complaints'): ?>
                <div class="card complaint-section">
                    <h3>My Complaints</h3>
                    <?php if ($my_complaints_result->num_rows > 0): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Category</th>
                                    <th>Complaint</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($complaint = $my_complaints_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($complaint['complaint_id']); ?></td>
                                        <td><?php echo htmlspecialchars($complaint['category']); ?></td>
                                        <td><?php echo htmlspecialchars($complaint['complaint_text']); ?></td>
                                        <td><?php echo htmlspecialchars($complaint['created_at']); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>No complaints found.</p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <p>Invalid section selected.</p>
            <?php endif; ?>
            <a href="?section=my_complaints" class="button">My Complaints</a>
        </div>
    </main>
</body>
</html>
