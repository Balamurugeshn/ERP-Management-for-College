<?php
session_start();
include("db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch study materials
$materials_query = "SELECT * FROM study_materials WHERE student_id = ?";
$stmt = $conn->prepare($materials_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$materials_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Materials</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            line-height: 1.6;
        }
        header, footer {
            background-color: #003366;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        main {
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }
        .section {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .section h2 {
            font-size: 1.6em;
            margin-bottom: 10px;
        }
        .section table {
            width: 100%;
            border-collapse: collapse;
        }
        .section table, .section th, .section td {
            border: 1px solid #ddd;
        }
        .section th, .section td {
            padding: 10px;
            text-align: left;
        }
        .section th {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <header>
        <h1>Study Materials</h1>
    </header>
    <main>
        <div class="section">
            <h2>Your Study Materials</h2>
            <table>
                <tr>
                    <th>Subject</th>
                    <th>Material</th>
                </tr>
                <?php while ($row = $materials_result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['subject']); ?></td>
                    <td><a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank">Download</a></td>
                </tr>
                <?php } ?>
            </table>
        </div>
    </main>
    <footer>
        &copy; 2024 SMTECConnect+
    </footer>
</body>
</html>
