<?php
session_start();
include("db.php");

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'faculty') {
    header('Location: login.php');
    exit();
}

// Handle marking attendance for today
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['mark_attendance'])) {
    $date = date('Y-m-d');
    $status = $_POST['status'];
    $remarks = $_POST['remarks'];
    $user_id = $_POST['user_id'];

    // Check if attendance already exists for today
    $check_query = "SELECT * FROM attendance WHERE user_id='$user_id' AND date='$date'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        // Update existing record
        $update_query = "UPDATE attendance SET status='$status', remarks='$remarks' WHERE user_id='$user_id' AND date='$date'";
        mysqli_query($conn, $update_query);
    } else {
        // Insert new record
        $insert_query = "INSERT INTO attendance (user_id, date, status, remarks) VALUES ('$user_id', '$date', '$status', '$remarks')";
        mysqli_query($conn, $insert_query);
    }
}

// Handle attendance updates for existing records
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_attendance'])) {
    $attendance_id = $_POST['attendance_id'];
    $new_status = $_POST['status'];
    $update_query = "UPDATE attendance SET status='$new_status' WHERE attendance_id='$attendance_id'";
    mysqli_query($conn, $update_query);
}

// Fetch students for marking attendance
$students_query = "SELECT user_id, username FROM users WHERE role='student'";
$students_result = mysqli_query($conn, $students_query);

// Fetch attendance records for updating
$attendance_query = "
    SELECT a.attendance_id, u.username, a.date, a.status, a.remarks
    FROM attendance a
    JOIN users u ON a.user_id = u.user_id
    ORDER BY u.username, a.date
";
$attendance_result = mysqli_query($conn, $attendance_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty - Manage Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .form-section {
            margin-bottom: 20px;
        }
        .form-section form {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Faculty - Manage Attendance</h1>
    
    <!-- Section for Marking Attendance -->
    <div class="form-section">
        <h2>Mark Attendance for Today</h2>
        <form method="POST">
            <label for="student">Student:</label>
            <select name="user_id" id="student" required>
                <?php while ($student = mysqli_fetch_assoc($students_result)) { ?>
                    <option value="<?php echo $student['user_id']; ?>"><?php echo htmlspecialchars($student['username']); ?></option>
                <?php } ?>
            </select>
            <label for="status">Status:</label>
            <select name="status" id="status" required>
                <option value="Present">Present</option>
                <option value="Absent">Absent</option>
                <option value="On Duty">On Duty</option>
            </select>
            <label for="remarks">Remarks:</label>
            <textarea name="remarks" id="remarks" rows="3" placeholder="Enter remarks (optional)"></textarea>
            <button type="submit" name="mark_attendance">Mark Attendance</button>
        </form>
    </div>

    <!-- Section for Updating Attendance -->
    <div class="form-section">
        <h2>Update Existing Attendance</h2>
        <table>
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Remarks</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($attendance_result)) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td><?php echo htmlspecialchars($row['date']); ?></td>
                        <td>
                            <form method="POST">
                                <input type="hidden" name="attendance_id" value="<?php echo $row['attendance_id']; ?>">
                                <select name="status">
                                    <option value="Present" <?php if ($row['status'] == 'Present') echo 'selected'; ?>>Present</option>
                                    <option value="Absent" <?php if ($row['status'] == 'Absent') echo 'selected'; ?>>Absent</option>
                                    <option value="On Duty" <?php if ($row['status'] == 'On Duty') echo 'selected'; ?>>On Duty</option>
                                </select>
                                <button type="submit" name="update_attendance">Update</button>
                            </form>
                        </td>
                        <td><?php echo htmlspecialchars($row['remarks']); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
