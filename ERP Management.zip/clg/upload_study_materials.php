<?php
session_start();
include("db.php");

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'faculty') {
    header('Location: login.php');
    exit();
}

// Handle uploading study material
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['upload_material'])) {
    $subject_id = $_POST['id'];
    $title = $_POST['title'];
    
    if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $file_name = basename($_FILES['file']['name']);
        $file_path = 'uploads' . $file_name;
        
        // Move uploaded file to the server
        if (move_uploaded_file($_FILES['file']['tmp_name'], $file_path)) {
            $faculty_id = $_SESSION['user_id'];
            $insert_query = "INSERT INTO study_materials (faculty_id, subject_id, material_title, material_file) 
                             VALUES ('$faculty_id', '$subject_id', '$title', '$file_name')";
            mysqli_query($conn, $insert_query);
            echo "Study material uploaded successfully.";
        } else {
            echo "Failed to upload file.";
        }
    } else {
        echo "No file uploaded or error during file upload.";
    }
}

// Fetch available subjects
$subjects_query = "SELECT id, subject_name FROM subjects";
$subjects_result = mysqli_query($conn, $subjects_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty - Upload Study Material</title>
    <style>
        /* Add your styles here */
    </style>
</head>
<body>
    <h1>Faculty - Upload Study Material</h1>
    
    <!-- Section for Uploading Study Material -->
    <div>
        <form method="POST" enctype="multipart/form-data">
            <label for="subject">Subject:</label>
            <select name="id" id="subject" required>
                <?php while ($subject = mysqli_fetch_assoc($subjects_result)) { ?>
                    <option value="<?php echo $subject['id']; ?>"><?php echo htmlspecialchars($subject['subject_name']); ?></option>
                <?php } ?>
            </select>
            <label for="title">Title:</label>
            <input type="text" name="title" id="title" required>
            <label for="file">File:</label>
            <input type="file" name="file" id="file" required>
            <button type="submit" name="upload_material">Upload</button>
        </form>
    </div>
</body>
</html>
