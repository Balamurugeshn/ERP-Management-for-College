<?php
session_start();
include("db.php");

// Handle updating marks
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $mark_id = $_POST['mark_id'];
    $new_marks = $_POST['marks'];
    
    // Validate new marks
    if (is_numeric($new_marks) && $new_marks >= 0 && $new_marks <= 100) {
        $update_query = "UPDATE student_marks SET marks='$new_marks' WHERE id='$mark_id'";
        if (mysqli_query($conn, $update_query)) {
            echo "Marks updated successfully.";
        } else {
            echo "Error updating marks.";
        }
    } else {
        echo "Invalid marks. Please enter a number between 0 and 100.";
    }
}
?>
