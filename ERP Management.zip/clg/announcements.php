<?php
session_start(); // Start the session at the very beginning of the file

include("db.php");

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $conn->real_escape_string($_POST['title']);
    $content = $conn->real_escape_string($_POST['content']);
    $username = $conn->real_escape_string($_SESSION['username']);
    $created_at = date('Y-m-d H:i:s');
    $expires_at = date('Y-m-d H:i:s', strtotime('+1 week')); // Set expiry to 1 week from now

    // Insert new announcement
    $sql = "INSERT INTO announcements (title, content, username, created_at, expires_at) VALUES ('$title', '$content', '$username', '$created_at', '$expires_at')";
    if ($conn->query($sql) === TRUE) {
        echo "<p>Announcement created successfully.</p>";
    } else {
        echo "<p>Error: " . $conn->error . "</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Announcements</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            line-height: 1.6;
        }

        /* Header Styling */
        header {
            background-color: #003366;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        header h1 {
            margin-bottom: 10px;
        }

        nav ul {
            list-style: none;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin: 0 15px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            transition: background 0.3s;
        }

        nav ul li a:hover {
            background-color: #00509e;
            border-radius: 5px;
        }

        /* Main Content Styling */
        main {
            padding: 20px;
            max-width: 900px;
            margin: 0 auto;
        }

        .announcement {
            position: relative;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .announcement h2 {
            font-size: 1.6em;
            margin-bottom: 10px;
        }

        .announcement .date {
            font-size: 0.9em;
            color: #666;
            margin-bottom: 15px;
        }

        .announcement .username {
            font-size: 0.9em;
            color: #666;
            margin-bottom: 15px;
        }

        .announcement p {
            font-size: 1.1em;
            line-height: 1.5;
        }

        /* Delete Button Styling */
        .delete-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: transparent;
            border: none;
            cursor: pointer;
            color: #d9534f;
            font-size: 1.2em;
        }

        .delete-btn:hover {
            color: #c9302c;
        }

        /* Form Styling */
        .announcement-form {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .announcement-form h2 {
            margin-bottom: 15px;
        }

        .announcement-form input, 
        .announcement-form textarea, 
        .announcement-form button {
            width: 100%;
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        .announcement-form button {
            background-color: #003366;
            color: #fff;
            border: none;
            cursor: pointer;
            font-size: 1em;
        }

        .announcement-form button:hover {
            background-color: #00509e;
        }

        /* Footer Styling */
        footer {
            background-color: #003366;
            color: #fff;
            text-align: center;
            padding: 15px;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>Admin Announcements</h1>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="announcements.php">Announcements</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="announcement-form">
            <h2>Create Announcement</h2>
            <form action="announcements.php" method="post">
                <input type="text" name="title" placeholder="Announcement Title" required>
                <textarea name="content" rows="5" placeholder="Announcement Content" required></textarea>
                <button type="submit">Submit Announcement</button>
            </form>
        </div>

        <!-- Display announcements -->
        <?php
        $result = $conn->query("SELECT announcement_id, title, content, username, created_at FROM announcements WHERE expires_at > NOW() ORDER BY created_at DESC");
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="announcement">';
                // Add delete button with Font Awesome trash icon
                echo '<form action="delete_announcement.php" method="post" class="delete-form" onsubmit="return confirm(\'Are you sure you want to delete this announcement?\');">';
                echo '<input type="hidden" name="announcement_id" value="' . htmlspecialchars($row['announcement_id']) . '">';
                echo '<button type="submit" class="delete-btn"><i class="fa-solid fa-trash"></i></button>';
                echo '</form>';
                
                echo '<h2>' . htmlspecialchars($row['title']) . '</h2>';
                echo '<div class="date">Posted on: ' . htmlspecialchars($row['created_at']) . '</div>';
                echo '<div class="username">Posted by: ' . htmlspecialchars($row['username']) . '</div>';
                echo '<p>' . htmlspecialchars($row['content']) . '</p>';
                echo '</div>';
            }
        } else {
            echo "<p>Error: " . $conn->error . "</p>";
        }

        $conn->close(); // Close the database connection
        ?>
    </main>
    <footer>
        &copy; 2024 SMTECConnect+
    </footer>
</body>
</html>
