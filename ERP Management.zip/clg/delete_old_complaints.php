<?php
include 'db.php'; // Ensure this file contains the database connection setup

// Calculate the date one week ago from today
$one_week_ago = date('Y-m-d H:i:s', strtotime('-1 week'));

// Prepare and execute the delete query
$query = "DELETE FROM complaints WHERE created_at < ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $one_week_ago);

if ($stmt->execute()) {
    // Complaints older than one week have been deleted
}

$stmt->close();
$conn->close();
?>
