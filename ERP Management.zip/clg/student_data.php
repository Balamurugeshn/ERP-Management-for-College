<?php
session_start();
include("db.php");

// Ensure that session variables are set
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Fetch departments for the filter dropdown
$departments_query = "SELECT DISTINCT department FROM users WHERE role = 'student'";
$departments_result = mysqli_query($conn, $departments_query);

// Check for query errors
if (!$departments_result) {
    die("Query failed: " . mysqli_error($conn));
}

// Handle department filter
$selected_department = '';
if (isset($_POST['department'])) {
    $selected_department = mysqli_real_escape_string($conn, $_POST['department']);
}

// Fetch student data from the database with filtering
$query = "SELECT * FROM users WHERE role = 'student'";
if ($selected_department) {
    $query .= " AND department = '$selected_department'";
}
$result = mysqli_query($conn, $query);

// Check for query errors
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

// Handle form submission for updating student data
if (isset($_POST['update_student'])) {
    $student_id = intval($_POST['user_id']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);
    $class = mysqli_real_escape_string($conn, $_POST['class']);
    $section = mysqli_real_escape_string($conn, $_POST['section']);
    $mobile_number = mysqli_real_escape_string($conn, $_POST['mobile_number']);
    
    $update_query = "UPDATE users SET username='$username', email='$email', department='$department', class='$class', section='$section', mobile_number='$mobile_number' WHERE id=$student_id";
    if (mysqli_query($conn, $update_query)) {
        // If the updated user is the currently logged-in user, update the session variables
        if ($_SESSION['username'] == $username) {
            $_SESSION['role'] = $role;
        }
        
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    document.getElementById('update-dialog').style.display = 'block';
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000); // Reload after 2 seconds
                });
              </script>";
    } else {
        $update_error = "Failed to update student data: " . mysqli_error($conn);
    }
}

// Handle student deletion
if (isset($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    $delete_query = "DELETE FROM users WHERE id = $delete_id";
    if (mysqli_query($conn, $delete_query)) {
        header('Location: student_data.php');
        exit();
    } else {
        $delete_error = "Failed to delete student: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Student Data</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: #003366;
            color: #fff;
            padding: 10px 0;
            text-align: center;
            position: sticky;
            top: 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        header h1 {
            margin: 0;
            display: inline-block;
        }
        .add-student {
            float: right;
            margin: 10px 20px;
            background-color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 20px auto;
        }
        .department-select {
            margin-bottom: 20px;
        }
        .department-select form {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .department-select label {
            font-weight: bold;
        }
        .department-select select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            border-radius: 5px;
            overflow: hidden;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #003366;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .edit-form {
            background-color: #003366;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .edit-form input[type="text"], 
        .edit-form input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .edit-form button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .edit-form button:hover {
            background-color: #0056b3;
        }
        .dialog-box {
            display: none;
            position: fixed;
            top: 10%; /* Move the dialog box higher */
            left: 50%;
            transform: translateX(-50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        .dialog-box p {
            margin: 0;
        }
        .dialog-box button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .dialog-box button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<header>
    <h1>Manage Student Data</h1>
    <a href="add_student.php" class="add-student">Add Student</a>
</header>

<div class="container">
    <div class="department-select">
        <form method="post" action="">
            <label for="department">Select Department:</label>
            <select name="department" id="department" onchange="this.form.submit()">
                <option value="">-- All Departments --</option>
                <?php
                if (mysqli_num_rows($departments_result) > 0) {
                    while ($dept_row = mysqli_fetch_assoc($departments_result)) {
                        $dept = htmlspecialchars($dept_row['department']);
                        $selected = ($dept == $selected_department) ? 'selected' : '';
                        echo "<option value='$dept' $selected>$dept</option>";
                    }
                }
                ?>
            </select>
        </form>
    </div>

    <!-- Display student data -->
    <h2>Student List</h2>
    <?php if (isset($update_success)) { ?>
        <div class="dialog-box" id="update-dialog">
            <p>Student data updated successfully.</p>
            <button onclick="closeDialog()">Close</button>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                document.getElementById('update-dialog').style.display = 'block';
                setTimeout(function() {
                    window.location.reload();
                }, 2000); // Reload after 2 seconds
            });
            function closeDialog() {
                document.getElementById('update-dialog').style.display = 'none';
            }
        </script>
    <?php } ?>
    <?php if (isset($update_error)) { ?>
        <p><?php echo $update_error; ?></p>
    <?php } ?>
    <?php if (isset($delete_error)) { ?>
        <p><?php echo $delete_error; ?></p>
    <?php } ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Department</th>
                <th>Class</th>
                <th>Section</th>
                <th>Mobile Number</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $id = htmlspecialchars($row['user_id']); // Corrected key to 'id'
                    $username = htmlspecialchars($row['username']);
                    $email = htmlspecialchars($row['email']);
                    $department = isset($row['department']) ? htmlspecialchars($row['department']) : '';
                    $class = isset($row['class']) ? htmlspecialchars($row['class']) : '';
                    $section = isset($row['section']) ? htmlspecialchars($row['section']) : '';
                    $mobile_number = isset($row['mobile_number']) ? htmlspecialchars($row['mobile_number']) : '';
                
                    echo "<tr>";
                    echo "<td>$id</td>";
                    echo "<td>$username</td>";
                    echo "<td>$email</td>";
                    echo "<td>$department</td>";
                    echo "<td>$class</td>";
                    echo "<td>$section</td>";
                    echo "<td>$mobile_number</td>";
                    echo "<td><a href='edit_student.php?id=$id'>Edit</a> | <a href='student_data.php?delete=$id' onclick='return confirm(\"Are you sure?\")'>Delete</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No students found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
