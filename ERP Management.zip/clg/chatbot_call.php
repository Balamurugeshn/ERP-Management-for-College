<?php
function callChatGPT($message) {
    $apiKey = 'sk-SnaqfyWbWVt_rXbNuYw4XAczTRvHrP3J5hKlqTIa9GT3BlbkFJuZsemJzHHIUISxdZAu7fzwSGJDD4fWrEq4veCMeRcA';
    $apiUrl = 'https://api.openai.com/v1/chat/completions';

    $data = [
        'model' => 'gpt-3.5-turbo',
        'messages' => [
            ['role' => 'user', 'content' => $message]
        ],
        'max_tokens' => 150,
        'temperature' => 0.7
    ];

    $options = [
        'http' => [
            'header'  => "Content-Type: application/json\r\n" .
                         "Authorization: Bearer $apiKey\r\n",
            'method'  => 'POST',
            'content' => json_encode($data),
        ],
    ];
    
    $context  = stream_context_create($options);
    $response = file_get_contents($apiUrl, false, $context);

    if ($response === FALSE) {
        die('Error occurred');
    }

    $responseData = json_decode($response, true);
    return $responseData['choices'][0]['message']['content'];
}

// Example usage
$userMessage = 'Hello, how can I help you today?';
$responseMessage = callChatGPT($userMessage);
echo $responseMessage;
?>
