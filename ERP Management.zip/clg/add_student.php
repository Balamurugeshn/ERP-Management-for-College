<?php
session_start();
include("db.php");

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

if (isset($_POST['add_student'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);
    $class = mysqli_real_escape_string($conn, $_POST['class']);
    $section = mysqli_real_escape_string($conn, $_POST['section']);
    $mobile_number = mysqli_real_escape_string($conn, $_POST['mobile_number']);
    $password = password_hash(mysqli_real_escape_string($conn, $_POST['password']), PASSWORD_DEFAULT);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $dob = mysqli_real_escape_string($conn, $_POST['dob']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);

    // Check if the username already exists
    $check_user_query = "SELECT user_id FROM users WHERE username='$username'";
    $check_user_result = mysqli_query($conn, $check_user_query);

    if (mysqli_num_rows($check_user_result) > 0) {
        $user_row = mysqli_fetch_assoc($check_user_result);
        $user_id = $user_row['user_id'];

        // Update user details
        $update_user_query = "UPDATE users SET email='$email', department='$department', class='$class', section='$section', mobile_number='$mobile_number' WHERE user_id=$user_id";

        if (!mysqli_query($conn, $update_user_query)) {
            die("Failed to update user details: " . mysqli_error($conn));
        }

        // Update password if provided
        if (!empty($_POST['password'])) {
            $hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $update_password_query = "UPDATE users SET password='$hashed_password' WHERE user_id=$user_id";

            if (!mysqli_query($conn, $update_password_query)) {
                die("Failed to update password: " . mysqli_error($conn));
            }
        }

        // Update student profile details
        $update_profile_query = "INSERT INTO student_profiles (user_id, name, dob, address, department, class, section, mobile_number, email)
                                 VALUES ($user_id, '$name', '$dob', '$address', '$department', '$class', '$section', '$mobile_number', '$email')
                                 ON DUPLICATE KEY UPDATE name='$name', dob='$dob', address='$address', department='$department', class='$class', section='$section', mobile_number='$mobile_number', email='$email'";

        if (!mysqli_query($conn, $update_profile_query)) {
            die("Failed to update student profile details: " . mysqli_error($conn));
        }

    } else {
        // Insert new user
        $insert_user_query = "INSERT INTO users (username, email, department, class, section, mobile_number, password, role)
                              VALUES ('$username', '$email', '$department', '$class', '$section', '$mobile_number', '$password', 'student')";

        if (!mysqli_query($conn, $insert_user_query)) {
            die("Failed to add student: " . mysqli_error($conn));
        }

        // Get the newly inserted user_id
        $user_id = mysqli_insert_id($conn);

        // Insert student profile details
        $insert_profile_query = "INSERT INTO student_profiles (user_id, name, dob, address, department, class, section, mobile_number, email)
                                 VALUES ($user_id, '$name', '$dob', '$address', '$department', '$class', '$section', '$mobile_number', '$email')";

        if (!mysqli_query($conn, $insert_profile_query)) {
            die("Failed to insert student profile details: " . mysqli_error($conn));
        }
    }

    header('Location: student_data.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: #007bff;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
        }
        .container {
            width: 60%;
            margin: 20px auto;
        }
        .add-form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .add-form input[type="text"], 
        .add-form input[type="email"], 
        .add-form input[type="password"], 
        .add-form input[type="date"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .add-form button {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .add-form button:hover {
            background-color: #0056b3;
        }
        .add-form .error {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<header>
    <h1>Add Student</h1>
</header>

<div class="container">
    <div class="add-form">
        <form action="add_student.php" method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="name" placeholder="Name" required>
            <input type="date" name="dob" placeholder="Date of Birth" required>
            <input type="text" name="address" placeholder="Address" required>
            <input type="text" name="department" placeholder="Department" required>
            <input type="text" name="class" placeholder="Class" required>
            <input type="text" name="section" placeholder="Section" required>
            <input type="text" name="mobile_number" placeholder="Mobile Number" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="add_student">Add Student</button>
        </form>
        <?php if (isset($add_error)) { ?>
            <p class="error"><?php echo $add_error; ?></p>
        <?php } ?>
    </div>
</div>

</body>
</html>
