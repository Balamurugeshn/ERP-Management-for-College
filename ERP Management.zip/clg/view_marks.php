<?php
session_start();
include("db.php");

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'student') {
    header('Location: login.php');
    exit();
}

// Check if the student_id is set in the session
if (!isset($_SESSION['user_id'])) {
    echo "Student ID is not set in the session.";
    exit();
}

// Get the logged-in student's ID
$student_id = $_SESSION['user_id'];

// Fetch student marks
$marks_query = "
    SELECT s.subject_name, sm.marks
    FROM student_marks sm
    JOIN subjects s ON sm.subject_id = s.id
    WHERE sm.student_id = '$student_id'
    ORDER BY s.subject_name
";
$marks_result = mysqli_query($conn, $marks_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Marks</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <h1>Your Marks</h1>
    <table>
        <thead>
            <tr>
                <th>Subject</th>
                <th>Marks</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($marks_result)) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['marks']); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
