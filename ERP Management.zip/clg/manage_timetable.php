<?php
session_start();
include("db.php");

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'faculty') {
    header('Location: login.php');
    exit();
}

// Handle adding subjects to timetable
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_timetable'])) {
    $subject_id = $_POST['subject_id'];
    $date = $_POST['date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $user_id = $_SESSION['user_id'];

    $insert_query = "INSERT INTO timetables (user_id, subject_id, date, start_time, end_time) 
                     VALUES ('$user_id', '$subject_id', '$date', '$start_time', '$end_time')";
    mysqli_query($conn, $insert_query);
}

// Handle viewing timetable for a specific day
$view_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$timetable_query = "
    SELECT s.subject_name, t.date, t.start_time, t.end_time
    FROM timetables t
    JOIN subjects s ON t.subject_id = s.id  -- Adjust 's.id' to the correct column name
    WHERE t.user_id = '{$_SESSION['user_id']}' AND t.date = '$view_date'
";
$timetable_result = mysqli_query($conn, $timetable_query);

// Fetch available subjects
$subjects_query = "SELECT id, subject_name FROM subjects";  // Adjust 'id' to the correct column name
$subjects_result = mysqli_query($conn, $subjects_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty - Generate Timetable</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .form-section {
            margin-bottom: 20px;
        }
        .form-section form {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Faculty - Generate Timetable</h1>
    
    <!-- Section for Adding Timetable -->
    <div class="form-section">
        <h2>Add Timetable Entry</h2>
        <form method="POST">
            <label for="subject">Subject:</label>
            <select name="subject_id" id="subject" required>
                <?php while ($subject = mysqli_fetch_assoc($subjects_result)) { ?>
                    <option value="<?php echo $subject['id']; ?>"><?php echo htmlspecialchars($subject['subject_name']); ?></option>
                <?php } ?>
            </select>
            <label for="date">Date:</label>
            <input type="date" name="date" id="date" required>
            <label for="start_time">Start Time:</label>
            <input type="time" name="start_time" id="start_time" required>
            <label for="end_time">End Time:</label>
            <input type="time" name="end_time" id="end_time" required>
            <button type="submit" name="add_timetable">Add Timetable Entry</button>
        </form>
    </div>

    <!-- Section for Viewing Timetable -->
    <div class="form-section">
        <h2>View Timetable for a Specific Day</h2>
        <form method="GET">
            <label for="view_date">Date:</label>
            <input type="date" name="date" id="view_date" value="<?php echo htmlspecialchars($view_date); ?>" required>
            <button type="submit">View Timetable</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>Subject</th>
                    <th>Date</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($timetable_result)) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['date']); ?></td>
                        <td><?php echo htmlspecialchars($row['start_time']); ?></td>
                        <td><?php echo htmlspecialchars($row['end_time']); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
