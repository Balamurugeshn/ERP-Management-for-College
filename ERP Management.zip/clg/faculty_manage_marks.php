<?php
session_start();
include("db.php");

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'faculty') {
    header('Location: login.php');
    exit();
}

if (!isset($_SESSION['user_id'])) {
    echo "Faculty ID is not set in the session.";
    exit();
}

// Get the logged-in faculty member's ID
$faculty_id = $_SESSION['user_id'];

// Fetch subjects assigned to the faculty member
$subjects_query = "SELECT s.id AS subject_id, s.subject_name 
                   FROM faculty_subjects fs 
                   JOIN subjects s ON fs.subject_id = s.id 
                   WHERE fs.faculty_id = '$faculty_id'";
$subjects_result = mysqli_query($conn, $subjects_query);
$faculty_subjects = [];
while ($row = mysqli_fetch_assoc($subjects_result)) {
    $faculty_subjects[$row['subject_id']] = $row['subject_name'];
}

// Fetch student marks for the subjects taught by the faculty
$subject_ids = implode(',', array_keys($faculty_subjects));
$marks_query = "
    SELECT sm.id, st.student_name, s.subject_name, sm.marks
    FROM student_marks sm
    JOIN students st ON sm.student_id = st.id
    JOIN subjects s ON sm.subject_id = s.id
    WHERE sm.subject_id IN ($subject_ids)
    ORDER BY st.student_name, s.subject_name
";
$marks_result = mysqli_query($conn, $marks_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Student Marks</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <h1>Manage Student Marks</h1>
    <table>
        <thead>
            <tr>
                <th>Student Name</th>
                <th>Subject</th>
                <th>Marks</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($marks_result)) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                    <td>
                        <form class="update-form">
                            <input type="hidden" name="mark_id" value="<?php echo $row['id']; ?>">
                            <input type="number" name="marks" value="<?php echo $row['marks']; ?>" min="0" max="100">
                            <button type="submit">Update</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <script>
        $(document).ready(function() {
            $('.update-form').on('submit', function(e) {
                e.preventDefault(); // Prevent form from submitting normally
                
                var form = $(this);
                var formData = form.serialize(); // Serialize form data
                
                $.ajax({
                    type: 'POST',
                    url: 'update_marks.php', // URL to send the POST request
                    data: formData,
                    success: function(response) {
                        alert(response); // Display response from the server
                    }
                });
            });
        });
    </script>
</body>
</html>
