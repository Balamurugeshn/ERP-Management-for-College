<?php
session_start();
include 'db.php'; // Ensure this file contains the database connection setup

// Check if the user is logged in and has the role of 'admin'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: entry.php");
    exit();
}

// Handle complaint response
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['respond_complaint'])) {
    $complaint_id = $_POST['complaint_id'];
    $response_text = "Your grievances have been sorted quickly.";
    
    if (empty($complaint_id)) {
        $error_message = "Complaint ID is required.";
    } else {
        // Update complaint status and response
        $update_query = "UPDATE complaints SET status = 'read', response_text = ? WHERE complaint_id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("si", $response_text, $complaint_id);
        
        if ($stmt->execute()) {
            // Get the user's email address and ID
            $complaint_query = "SELECT u.email, u.user_id FROM complaints c JOIN users u ON c.user_id = u.user_id WHERE c.complaint_id = ?";
            $stmt = $conn->prepare($complaint_query);
            $stmt->bind_param("i", $complaint_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $user_email = $user['email'];
            $user_id = $user['user_id'];
            
            // Insert notification into the database
            $notification_query = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
            $stmt = $conn->prepare($notification_query);
            $stmt->bind_param("is", $user_id, $response_text);
            $stmt->execute();
            
            // Send email notification
            $subject = "Complaint Response";
            $message = "Dear User,\n\n" . $response_text . "\n\nThank you.";
            $headers = "From: nsbala2204@gmail.com";
            
            if (mail($user_email, $subject, $message, $headers)) {
                $success_message = "Complaint marked as read, response sent, and notification created.";
            } else {
                $error_message = "Failed to send notification email.";
            }
        } else {
            $error_message = "Failed to update complaint. Please try again.";
        }
        
        $stmt->close();
    }
}

// Fetch all complaints from students and faculty
$complaints_query = "
    SELECT c.complaint_id, c.user_id, c.category, c.complaint_text, c.created_at, c.status, u.role
    FROM complaints c
    JOIN users u ON c.user_id = u.user_id
    ORDER BY c.created_at DESC
";
$complaints_result = $conn->query($complaints_query);

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Complaints</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            line-height: 1.6;
            margin: 0;
        }
        header, footer {
            background-color: #003366;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        main {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .card, .complaint-section {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .complaint-section h3 {
            margin-top: 0;
        }
        .complaint-section table {
            width: 100%;
            border-collapse: collapse;
        }
        .complaint-section table, .complaint-section th, .complaint-section td {
            border: 1px solid #ddd;
        }
        .complaint-section th, .complaint-section td {
            padding: 10px;
            text-align: left;
        }
        .complaint-section th {
            background-color: #f4f4f4;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group select, .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-group button {
            background-color: #003366;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color: #002244;
        }
        .message {
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <header>
        <h1>Manage Complaints</h1>
    </header>
    <main>
        <div class="card">
            <a href="admin_dashboard.php" class="button">Back to Dashboard</a>
            <?php if (isset($success_message)): ?>
                <div class="message success"><?php echo $success_message; ?></div>
            <?php endif; ?>
            <?php if (isset($error_message)): ?>
                <div class="message error"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <div class="complaint-section">
                <h3>Complaints</h3>
                <?php if ($complaints_result->num_rows > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Category</th>
                                <th>Complaint</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($complaint = $complaints_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($complaint['complaint_id']); ?></td>
                                    <td><?php echo htmlspecialchars($complaint['category']); ?></td>
                                    <td><?php echo htmlspecialchars($complaint['complaint_text']); ?></td>
                                    <td><?php echo htmlspecialchars($complaint['created_at']); ?></td>
                                    <td><?php echo htmlspecialchars($complaint['status']); ?></td>
                                    <td>
                                        <?php if ($complaint['status'] === 'unread'): ?>
                                            <form method="post" action="">
                                                <input type="hidden" name="complaint_id" value="<?php echo htmlspecialchars($complaint['complaint_id']); ?>">
                                                <button type="submit" name="respond_complaint">Mark as Read and Respond</button>
                                            </form>
                                        <?php else: ?>
                                            Resolved
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No complaints available.</p>
                <?php endif; ?>
            </div>
        </div>
    </main>
</body>
</html>
