<?php
session_start();
include("db.php");

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Handle form submission
if (isset($_POST['update_faculty'])) {
    $id = intval($_POST['id']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $dob = mysqli_real_escape_string($conn, $_POST['dob']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $contact_number = mysqli_real_escape_string($conn, $_POST['contact_number']);
    $blood_group = mysqli_real_escape_string($conn, $_POST['blood_group']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);
    $designation = mysqli_real_escape_string($conn, $_POST['designation']);
    $qualifications = mysqli_real_escape_string($conn, $_POST['qualifications']);
    $experience_years = intval($_POST['experience_years']);
    $office_location = mysqli_real_escape_string($conn, $_POST['office_location']);
    $bio = mysqli_real_escape_string($conn, $_POST['bio']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Update user details
    $update_user_query = "UPDATE users SET username='$username', email='$email', department='$department', mobile_number='$contact_number' WHERE user_id=$id";
    if (!mysqli_query($conn, $update_user_query)) {
        die("Failed to update user details: " . mysqli_error($conn));
    }

    // Update password if a new one is provided
    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $update_password_query = "UPDATE users SET password='$hashed_password' WHERE id=$id";
        if (!mysqli_query($conn, $update_password_query)) {
            die("Failed to update password: " . mysqli_error($conn));
        }
    }

    // Update faculty profile details
    $update_profile_query = "UPDATE faculty_profiles SET Name='$name', dob='$dob', address='$address', contact_number='$contact_number', blood_group='$blood_group', gender='$gender', department='$department', designation='$designation', qualifications='$qualifications', experience_years=$experience_years, office_location='$office_location', bio='$bio' WHERE user_id=$id";

    if (!mysqli_query($conn, $update_profile_query)) {
        die("Failed to update faculty profile details: " . mysqli_error($conn));
    }

    header('Location: faculty_data.php');
    exit();
}

// Check if 'id' is set in the query parameters
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("No ID specified. Please include 'id' in the query parameters.");
}

$id = intval($_GET['id']);

// Fetch the existing details from the database
$query = "SELECT * FROM faculty_profiles WHERE user_id = $id";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    die("No such faculty profile found.");
}

$profile = mysqli_fetch_assoc($result);

// Fetch user details from the users table
$user_query = "SELECT * FROM users WHERE user_id = $id";
$user_result = mysqli_query($conn, $user_query);
$user = mysqli_fetch_assoc($user_result);

// Handle cases where gender might be missing
$gender_options = ['Male', 'Female', 'Other'];
$selected_gender = isset($profile['gender']) ? $profile['gender'] : '';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Faculty</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #007bff;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
        .container {
            width: 80%;
            margin: 20px auto;
        }
        .edit-form {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .edit-form h2 {
            margin-bottom: 20px;
            color: #007bff;
        }
        .edit-form input[type="text"],
        .edit-form input[type="email"],
        .edit-form input[type="date"],
        .edit-form input[type="number"],
        .edit-form input[type="password"],
        .edit-form select,
        .edit-form textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .edit-form button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .edit-form button:hover {
            background-color: #0056b3;
        }
        .edit-form label {
            display: block;
            margin: 10px 0 5px;
            color: #333;
        }
    </style>
</head>
<body>

<header>
    <h1>Edit Faculty</h1>
</header>

<div class="container">
    <div class="edit-form">
        <form action="" method="post">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($profile['Name']); ?>" required>
            <label for="dob">Date of Birth:</label>
            <input type="date" name="dob" id="dob" value="<?php echo htmlspecialchars($profile['dob']); ?>" required>
            <label for="address">Address:</label>
            <input type="text" name="address" id="address" value="<?php echo htmlspecialchars($profile['address']); ?>" required>
            <label for="contact_number">Contact Number:</label>
            <input type="text" name="contact_number" id="contact_number" value="<?php echo htmlspecialchars($profile['contact_number']); ?>" required>
            <label for="blood_group">Blood Group:</label>
<select name="blood_group" id="blood_group" required>
    <option value="">Select Blood Group</option>
    <option value="A+" <?php if ($profile['blood_group'] == 'A+') echo 'selected'; ?>>A+</option>
    <option value="A-" <?php if ($profile['blood_group'] == 'A-') echo 'selected'; ?>>A-</option>
    <option value="B+" <?php if ($profile['blood_group'] == 'B+') echo 'selected'; ?>>B+</option>
    <option value="B-" <?php if ($profile['blood_group'] == 'B-') echo 'selected'; ?>>B-</option>
    <option value="O+" <?php if ($profile['blood_group'] == 'O+') echo 'selected'; ?>>O+</option>
    <option value="O-" <?php if ($profile['blood_group'] == 'O-') echo 'selected'; ?>>O-</option>
    <option value="AB+" <?php if ($profile['blood_group'] == 'AB+') echo 'selected'; ?>>AB+</option>
    <option value="AB-" <?php if ($profile['blood_group'] == 'AB-') echo 'selected'; ?>>AB-</option>
</select>

            <label for="gender">Gender:</label>
            <select name="gender" id="gender" required>
                <option value="">Select Gender</option>
                <?php foreach ($gender_options as $option): ?>
                    <option value="<?php echo htmlspecialchars($option); ?>" <?php if ($option == $selected_gender) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($option); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <label for="department">Department:</label>
            <input type="text" name="department" id="department" value="<?php echo htmlspecialchars($user['department']); ?>" required>
            <label for="designation">Designation:</label>
            <input type="text" name="designation" id="designation" value="<?php echo htmlspecialchars($profile['designation']); ?>" required>
            <label for="qualifications">Qualifications:</label>
            <textarea name="qualifications" id="qualifications" rows="4" required><?php echo htmlspecialchars($profile['qualifications']); ?></textarea>
            <label for="experience_years">Experience (Years):</label>
            <input type="number" name="experience_years" id="experience_years" value="<?php echo htmlspecialchars($profile['experience_years']); ?>" required>
            <label for="office_location">Office Location:</label>
            <input type="text" name="office_location" id="office_location" value="<?php echo htmlspecialchars($profile['office_location']); ?>" required>
            <label for="bio">Bio:</label>
            <textarea name="bio" id="bio" rows="4" required><?php echo htmlspecialchars($profile['bio']); ?></textarea>
            <label for="password">Password (leave blank to keep current password):</label>
            <input type="password" name="password" id="password">
            <button type="submit" name="update_faculty">Update Faculty</button>
        </form>
    </div>
</div>

</body>
</html>
