<?php
session_start();
include("db.php");

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'student') {
    header('Location: login.php');
    exit();
}

// Handle file download
if (isset($_GET['download']) && !empty($_GET['file'])) {
    $file = basename($_GET['file']); // Prevent directory traversal attacks
    $file_path = __DIR__ . '/uploads/' . $file;
    
    if (file_exists($file_path)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        exit;
    } else {
        echo "File does not exist.";
    }
}

// Fetch study materials
$materials_query = "
    SELECT sm.material_id, sm.material_title, sm.material_file, s.subject_name
    FROM study_materials sm
    JOIN subjects s ON sm.subject_id = s.id
    WHERE sm.faculty_id IN (SELECT user_id FROM users WHERE role='faculty')
";
$materials_result = mysqli_query($conn, $materials_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student - View Study Materials</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        a {
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>Student - View Study Materials</h1>

    <table>
        <thead>
            <tr>
                <th>Title</th>
                <th>Subject</th>
                <th>Download</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($materials_result)) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['material_title']); ?></td>
                    <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                    <td>
                        <a href="view_materials.php?download=true&file=<?php echo urlencode($row['material_file']); ?>">Download</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
