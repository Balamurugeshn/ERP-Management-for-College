<?php
session_start();
include 'db.php'; // Ensure this file contains the database connection setup

// Check if the user is logged in and has the role of 'faculty'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'faculty') {
    header("Location: entry.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch faculty profile information
$profile_query = "SELECT * FROM faculty_profiles WHERE user_id = ?";
$stmt = $conn->prepare($profile_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$profile_result = $stmt->get_result();

if ($profile_result->num_rows > 0) {
    $profile = $profile_result->fetch_assoc();
} else {
    $_SESSION['error'] = "Profile not found!";
    header("Location: entry.php");
    exit();
}

// Fetch notifications for the logged-in faculty
$notifications_query = "SELECT * FROM announcements WHERE expires_at > NOW() ORDER BY created_at DESC";
$notifications_result = $conn->query($notifications_query);

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            line-height: 1.6;
            margin: 0;
        }
        header, footer {
            background-color: #003366;
            color: #fff;
            padding: 20px;
            text-align: center;
            position: relative;
        }
        
        main {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .profile-info, .card {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .profile-info h2, .card h3 {
            font-size: 1.6em;
            margin-bottom: 10px;
        }
        .profile-info table {
            width: 100%;
            border-collapse: collapse;
        }
        .profile-info table, .profile-info th, .profile-info td {
            border: 1px solid #ddd;
        }
        .profile-info th, .profile-info td {
            padding: 10px;
            text-align: left;
        }
        .profile-info th {
            background-color: #f4f4f4;
        }
        .profile-image-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        .profile-image {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .dashboard-cards {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .card {
            flex: 1;
            min-width: 250px;
        }
        .logout-button {
            background-color: #d9534f;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            position: absolute;
            right: 20px;
            top: 20px;
        }
        .logout-button:hover {
            background-color: #c9302c;
        }
        .edit-button {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background-color: #337ab7;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .edit-button:hover {
            background-color: #286090;
        }

        /* Notification Styles */
        .notification-bell {
            position: absolute;
            right: 70px;
            top: 20px;
            cursor: pointer;
            margin-left: 20px;
        }
        .notification-dropdown {
            display: none;
            position: absolute;
            top: 60px;
            right: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            width: 300px;
            max-height: 400px;
            overflow-y: auto;
            z-index: 1000;
        }
        .notification-dropdown.show {
            display: block;
        }
        .notification-item {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        .notification-item:last-child {
            border-bottom: none;
        }
        .notification-item.unread {
            background-color: #f9f9f9;
        }
        .notification-item a {
            text-decoration: none;
            color: #003366;
        }
        .notification-item a:hover {
            text-decoration: underline;
        }
        .notification-item .date {
            font-size: 0.9em;
            color: #666;
        }
    </style>
    <script>
        function toggleNotifications() {
            const dropdown = document.getElementById('notification-dropdown');
            dropdown.classList.toggle('show');
        }
    </script>
</head>
<body>
    <header>
        <h1>Faculty Dashboard</h1>
        <!-- Notification Bell Icon -->
        <img src="notification_bell_icon.png" alt="Notifications" class="notification-bell" onclick="toggleNotifications()">
        <!-- Logout Button -->
        <a href="logout.php" class="logout-button">Logout</a>
    </header>
    <main>
        <!-- Profile Information Section -->
        <div class="profile-info">
            <h2>Profile Information</h2>
            <!-- Centered Profile Picture -->
            <div class="profile-image-container">
                <img src="uploads/<?php echo htmlspecialchars($profile['profile_picture']); ?>" alt="Profile Picture" class="profile-image">
            </div>
            <table>
                <tr><th>Name</th><td><?php echo htmlspecialchars($profile['Name']); ?></td></tr>
                <tr><th>Email</th><td><?php echo htmlspecialchars($profile['email']); ?></td></tr>
                <tr><th>Department</th><td><?php echo htmlspecialchars($profile['department']); ?></td></tr>
                <tr><th>Designation</th><td><?php echo htmlspecialchars($profile['designation']); ?></td></tr>
                <tr><th>Qualifications</th><td><?php echo htmlspecialchars($profile['qualifications']); ?></td></tr>
                <tr><th>Office Location</th><td><?php echo htmlspecialchars($profile['office_location']); ?></td></tr>
            </table>
            <!-- Edit Profile Button -->
            <a href="edit_faculty_profile.php" class="edit-button">Edit Profile</a>
        </div>

        <!-- Dashboard Cards -->
        <div class="dashboard-cards">
            <!-- Marks Management Card -->
            <div class="card">
                <h3>Manage Marks</h3>
                <p>Manage and update student marks.</p>
                <a href="manage_marks.php">Manage Marks</a>
            </div>

            <!-- Attendance Management Card -->
            <div class="card">
                <h3>Manage Attendance</h3>
                <p>Track and update student attendance.</p>
                <a href="manage_attendance.php">Manage Attendance</a>
            </div>

            <!-- Study Materials Card -->
            <div class="card">
                <h3>Upload Study Materials</h3>
                <p>Upload and manage study materials for students.</p>
                <a href="upload_study_materials.php">Upload Materials</a>
            </div>

            <!-- Timetable Management Card -->
            <div class="card">
                <h3>Manage Timetable</h3>
                <p>Set and update class timetables.</p>
                <a href="manage_timetable.php">Manage Timetable</a>
            </div>

            <!-- Complaint Management Card -->
            <div class="card">
                <h3>Manage Complaints</h3>
                <p>Review and respond to complaints.</p>
                <a href="manage_complaints.php">Manage Complaints</a>
            </div>
        </div>
    </main>
    <!-- Notification Dropdown -->
    <div id="notification-dropdown" class="notification-dropdown">
        <?php
        if ($notifications_result->num_rows > 0) {
            while ($notification = $notifications_result->fetch_assoc()) {
                echo '<div class="notification-item">';
                echo '<a href="#">';
                echo '<div class="notification-title">' . htmlspecialchars($notification['title']) . '</div>';
                echo '<div class="notification-content">' . htmlspecialchars($notification['content']) . '</div>';
                echo '<div class="date">' . date('d M Y', strtotime($notification['created_at'])) . '</div>';
                echo '</a>';
                echo '</div>';
            }
        } else {
            echo '<div class="notification-item">No notifications available.</div>';
        }
        ?>
    </div>
    <footer>
        <p>© 2024 SMTECConnect+. All rights reserved.</p>
    </footer>
</body>
</html>
