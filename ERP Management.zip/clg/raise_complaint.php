<?php
session_start();
include 'db.php'; // Ensure this file contains the database connection setup

// Check if user is logged in and has the role of 'student'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: entry.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_complaint'])) {
    // Get form data
    $category = $_POST['category'];
    $complaint_text = $_POST['complaint_text'];

    // Validate inputs
    if (empty($category) || empty($complaint_text)) {
        $error_message = "All fields are required.";
    } else {
        // Insert complaint into the database
        $query = "INSERT INTO complaints (user_id, category, complaint_text, created_at) VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("iss", $user_id, $category, $complaint_text);

        if ($stmt->execute()) {
            $success_message = "Your complaint has been submitted successfully.";
        } else {
            $error_message = "Failed to submit your complaint. Please try again.";
        }

        $stmt->close();
    }
}

// Fetch complaints raised by the user if the 'My Complaints' button is clicked
$complaints = [];
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['view_complaints'])) {
    $query = "SELECT user_id, category, complaint_text, created_at FROM complaints WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $complaints[] = $row;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raise a Complaint</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5; /* Light grey background for better contrast */
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-top: 20px; /* Add some space at the top */
        }
        .header {
            background-color: #003366;
            color: #fff;
            padding: 15px;
            text-align: center;
            position: relative;
            border-radius: 8px 8px 0 0;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .header .btn-back-dashboard {
            position: absolute;
            right: 15px;
            top: 15px;
            background-color: #004080;
            padding: 10px 20px;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        .header .btn-back-dashboard:hover {
            background-color: #003366;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #003366;
        }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        .form-group textarea {
            resize: vertical;
        }
        .btn-submit {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        .btn-submit:hover {
            background-color: #002244;
        }
        .btn-view-complaints {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        .btn-view-complaints:hover {
            background-color: #002244;
        }
        .message {
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 5px;
        }
        .success {
            background-color: #dff0d8;
            color: #3c763d;
        }
        .error {
            background-color: #f2dede;
            color: #a94442;
        }
        .complaints-list {
            margin-top: 20px;
        }
        .complaint-item {
            background-color: #f9f9f9;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .complaint-item p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Raise a Complaint</h1>
            <a href="student-dashboard.php" class="btn-back-dashboard">Back to Dashboard</a>
        </div>
        <?php if (isset($success_message)) { ?>
            <div class="message success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php } ?>
        <?php if (isset($error_message)) { ?>
            <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
        <?php } ?>
        <form action="raise_complaint.php" method="POST">
            <div class="form-group">
                <label for="category">Complaint Category</label>
                <select id="category" name="category" required>
                    <option value="">Select Category</option>
                    <option value="canteen">Canteen</option>
                    <option value="restroom">Restroom</option>
                    <option value="department">Department</option>
                    <option value="ground">Ground</option>
                    <option value="campus">Campus</option>
                    <option value="faculty">Faculty</option>
                    <option value="others">Others</option>
                </select>
            </div>
            <div class="form-group">
                <label for="complaint_text">Complaint Details</label>
                <textarea id="complaint_text" name="complaint_text" rows="6" placeholder="Describe your complaint here..." required></textarea>
            </div>
            <button type="submit" name="submit_complaint" class="btn-submit">Submit Complaint</button>
        </form>

        <!-- Button to view 'My Complaints' -->
        <form action="raise_complaint.php" method="POST">
            <button type="submit" name="view_complaints" class="btn-view-complaints">View My Complaints</button>
        </form>

        <!-- Display the list of complaints -->
        <?php if (!empty($complaints)) { ?>
            <div class="complaints-list">
                <h2>My Complaints</h2>
                <?php foreach ($complaints as $complaint) { ?>
                    <div class="complaint-item">
                        <p><strong>Category:</strong> <?php echo htmlspecialchars($complaint['category']); ?></p>
                        <p><strong>Complaint:</strong> <?php echo htmlspecialchars($complaint['complaint_text']); ?></p>
                        <p><strong>Date:</strong> <?php echo htmlspecialchars($complaint['created_at']); ?></p>
                    </div>
                <?php } ?>
            </div>
        <?php } ?>
    </div>
</body>
</html>
