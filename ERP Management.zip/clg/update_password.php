<?php
session_start();
require 'db.php';  // Include your database connection

// Function to validate the password
function validate_password($password) {
    // Check if the password meets the constraints
    if (strlen($password) < 8 || strlen($password) > 20) {
        return "Password must be between 8 and 20 characters.";
    }
    if (!preg_match('/[0-9]/', $password)) {
        return "Password must contain at least one digit.";
    }
    if (!preg_match('/[A-Z]/', $password)) {
        return "Password must contain at least one upper case letter.";
    }
    if (!preg_match('/[a-z]/', $password)) {
        return "Password must contain at least one lower case letter.";
    }
    return true;
}

// Check if the form is submitted
if (isset($_POST['update_password'])) {
    $new_password = $_POST['new_password'];            // Get the new password from the form
    $confirm_password = $_POST['confirm_password'];    // Get the confirmation password

    // Validate the password and check if the confirmation matches
    $validation_result = validate_password($new_password);

    if ($validation_result === true) {
        if ($new_password === $confirm_password) {
            $email = $_SESSION['email'];               // Get the email from the session

            // Hash the new password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Update the password in the database
            $query = "UPDATE users SET password = ? WHERE email = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ss", $hashed_password, $email);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                // Password updated successfully, redirect to login page
                echo "Password updated successfully!";
                header("Location: login.php");
                exit();
            } else {
                echo "Failed to update password. Please try again.";
            }
        } else {
            echo "Passwords do not match. Please try again.";
        }
    } else {
        // Display validation error
        echo $validation_result;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 250px; /* Reduced the width for a more compact look */
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
            color: #333;
        }
        input[type="password"] {
            width: 100%;
            padding: 8px; /* Reduced padding */
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }
        button:hover {
            background-color: #0056b3;
        }
        .error {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Update Password</h2>
        <form action="update_password.php" method="post">
            <input type="password" name="new_password" placeholder="Enter New Password" required><br>
            <input type="password" name="confirm_password" placeholder="Confirm New Password" required><br>
            <button type="submit" name="update_password">Update Password</button>
        </form>
        <?php
        // Display any error messages (like password mismatch or validation errors)
        if (isset($error_message)) {
            echo "<div class='error'>$error_message</div>";
        }
        ?>
    </div>
</body>
</html>

