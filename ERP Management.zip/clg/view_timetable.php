<?php
session_start();
include("db.php");

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'student') {
    header('Location: login.php');
    exit();
}

// Handle viewing timetable for a specific day
$view_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$timetable_query = "
    SELECT s.subject_name, t.date, t.start_time, t.end_time
    FROM timetables t
    JOIN subjects s ON t.subject_id = s.id  -- Adjust 's.id' to the correct column name
    WHERE t.user_id IN (SELECT user_id FROM users WHERE role='faculty') 
      AND t.date = '$view_date'
";
$timetable_result = mysqli_query($conn, $timetable_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student - View Timetable</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .form-section {
            margin-bottom: 20px;
        }
        .form-section form {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Student - View Timetable</h1>
    
    <!-- Section for Viewing Timetable -->
    <div class="form-section">
        <h2>View Timetable for a Specific Day</h2>
        <form method="GET">
            <label for="view_date">Date:</label>
            <input type="date" name="date" id="view_date" value="<?php echo htmlspecialchars($view_date); ?>" required>
            <button type="submit">View Timetable</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>Subject</th>
                    <th>Date</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($timetable_result)) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['date']); ?></td>
                        <td><?php echo htmlspecialchars($row['start_time']); ?></td>
                        <td><?php echo htmlspecialchars($row['end_time']); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
