<?php
session_start();
require 'db.php';  // Include your database connection
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if (isset($_POST['send_otp'])) {
    $email = $_POST['email']; // Get the email entered by the user

    // Store the email in the session
    $_SESSION['email'] = $email;

    // Generate a 6-digit OTP
    $otp = rand(100000, 999999);

    // Save the OTP in the database
    $query = "UPDATE users SET otp = ? WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $otp, $email);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        // Send the OTP to the user's email
        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';  // Set the SMTP server to send through
            $mail->SMTPAuth = true;
            $mail->Username = 'nsbala2204@gmail.com';  // SMTP username
            $mail->Password = 'xkth uytw fgid qtly';  // SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;

            // Recipients
            $mail->setFrom('your_email@gmail.com', 'Your Name');
            $mail->addAddress($email);  // Add a recipient

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Your OTP Code';
            $mail->Body    = 'Your OTP code is: ' . $otp;

            $mail->send();

            // Show a success message using JavaScript
            echo "<script>
                    alert('OTP sent successfully');
                    window.location.href='verify_otp.php';
                  </script>";
            exit();
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "Failed to send OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send OTP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 350px; /* Moderate width for the container */
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
            color: #333;
        }
        input[type="email"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        button {
            padding: 10px 20px;
            background-color:  #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }
        button:hover {
            background-color: #0056b3;
        }
        .success {
            color: green;
            margin-top: 20px;
        }
        .error {
            color: red;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Send OTP</h2>
        <form action="send_otp.php" method="post">
            <input type="email" name="email" placeholder="Enter Your Email" required><br>
            <button type="submit" name="send_otp">Send OTP</button>
        </form>
        <?php
        // Display success or error messages
        if (isset($success_message)) {
            echo "<div class='success'>$success_message</div>";
        } elseif (isset($error_message)) {
            echo "<div class='error'>$error_message</div>";
        }
        ?>
    </div>
</body>
</html>

