<?php
session_start();
include("db.php");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch the announcement id from the form submission
    $announcement_id = $conn->real_escape_string($_POST['announcement_id']); 

    // Ensure you have a column named 'announcement_id' in your announcements table
    $sql = "DELETE FROM announcements WHERE announcement_id = '$announcement_id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: announcements.php"); // Redirect back to the announcements page after deletion
        exit;
    } else {
        echo "<p>Error deleting announcement: " . $conn->error . "</p>";
    }
}

$conn->close(); // Close the database connection
?>
